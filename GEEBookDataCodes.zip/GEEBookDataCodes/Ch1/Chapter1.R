###################chapter 1. introduction
###################################
#Example 1 HIV Diggle 2002
##################################
rm(list=ls())
setwd("C:/Aus/Gee-book/R-codeData")
library(lattice)
cd4<-as.data.frame(read.table(file="CD4_data.txt",header=TRUE, sep=""))


head(cd4,10)


#with(cd4,xyplot(CD4~time, group=as.factor(id),ylab="CD4+ ϸ����",xlab="ʱ��(��)",col=1, type="b"))


#savePlot(file="cd4.png",type="png")
############################################fig 1.1
with(cd4[1:132,],xyplot(CD4~time|as.factor(id),type="b",ylab="CD4+ ϸ����/��",xlab="ʱ��/��",col=1,layout=c(5,4)))
#savePlot(file="cd42.png",type="png")


###################################
#Example 2 Progabide study (Epileptic seizures)
##################################

proga<-as.data.frame(read.table(file="seizure.data",header=FALSE, sep=""))

names(proga)=c("ID", "Counts","Visit","Trt","Age","Weeks")
proga$ҩ��=as.factor(rep(c('��ο��','���޼ӱ�'), as.numeric(table(proga$Trt))))
head(proga,10)

#bwplot(as.factor(Visit)~sqrt(Counts)|ҩ��,  strip = strip.custom(strip.names = TRUE, strip.levels = TRUE),
# layout=c(1,2), ylab="���ʵĴ���",xlab=expression(sqrt(������)),data=proga, outline=TRUE)
#####################################fig 1.2
png("Fig1.2.png", width = 5, height = 5, units = 'in', res = 500)
xyplot(Counts~Visit|ҩ��, groups=factor(ID), strip = strip.custom(strip.names = TRUE, strip.levels = TRUE),
       layout=c(1,2), type="b",xlab="ʱ��",ylab="��������",data=proga, outline=TRUE, col=1)
dev.off()
#savePlot(file="proga.png",type="png")
#################################################fig 1.3
library(geepack)#seizure
data(seizure)
#count=matrix(proga$Counts,nc=5,byrow=T)
#count=seizure[1:5]
#colnames(count)=c("baseline","visit 1","visit 2","visit 3","visit 4")
colnames(seizure)[c(6,1:4)]=c("baseline","visit 1","visit 2","visit 3","visit 4")
seizure$trt=as.factor(seizure$trt)
pairs(seizure[c(6,1:4)],upper.panel=NULL,pch=21,bg = c("green","red")[unclass(seizure$trt)])

##############################################
mean1=with(proga,aggregate(Counts,by=list(Visit, Trt),mean))$x
var1=with(proga,aggregate(Counts,by=list(Visit, Trt),sd))$x^2
library(xtable)
xtable(rbind(mean1,var1),digits=3)
var1/mean1

###############################################################
###################################
#Example 3 Madras Schizophrenia study ��Diggle 2002��
##################################
mad<- read.table( file="madras.data.txt",sep="", header=TRUE)

# Name the variables according to madras.txt
colnames(mad) <- c(
  "ID",              # patient ID
  "Y",               # symptom indicator: binary
  "MONTH",           # month since hospitalization
  "AGE",             # age-at-onset (1= age<20 ; 0= age>=20)
  "GENDER",          # gender (1=female; 0=male)
  "MONTH.AGE",       # interaction term MONTH x AGE
  "MONTH.GENDER"     # interaction term MONTH x GENDER
)

head(mad,40)

##################################table 1.2
with(mad, ftable(Y,AGE,GENDER,MONTH))


###########################################
#Example 4 labor pain ��Jung 1996��
########################################
rm(list=ls())
setwd("C:/Aus/Gee-book/�����������ݷ���/R-codeData")
library(reshape)
library(lattice)
laborp=read.table(file="laborpain.txt",header=T,sep=" ")
head(laborp,10)
labor=reshape(laborp,varying=list(names(laborp)[-c(1,8)]), direction='long')

names(labor)=c("Patient","trt","Times","y","id")
labor=labor[!is.na(labor$y),]

labor=labor[order(labor$id),]
labor$TRT=rep(c("������","��ο����"),times=c(189,169))
###############################fig 1.4
bwplot(y~Times|TRT, data=labor,pars = list(boxwex = 0.15, staplewex = 0.25, outwex = 0.5),
       horizontal =F, groups=as.factor(trt),xlab="����ʱ��",ylab="��ʹ����",col=1,layout=c(1,2))

#############################fig 1.5
hist(labor$y,freq=F,main=" ",xlab=" ")


############################################
#Example 5
###############################################
exam5=read.table(file="laird.txt",header=T)

head(exam5)
sum(exam5$ct)


##########################################
#Example 6 pup
###########################################

pup=read.table(file="pupweights.txt",header=T)
head(pup)

levels(pup$dose)=c("������","�ͼ�����", "�߼�����")
levels(pup$gender)=c("Сĸ����","С������")
ni=as.numeric(table(pup$dam))

pup$size=rep(ni,times=ni)

dd=aggregate(pup$weight,by=list(pup$dam,pup$dose),FUN=mean)
dd=as.data.frame(dd)
colnames(dd)=c("Dam","Does","Weight")
dd$Dam=as.factor(dd$Dam)

dd=dd[order(dd$Dam),]
dd$ni=ni
xyplot(Weight~ ni, data=dd,groups=Does, xlab="ÿ��̥����Ŀ",ylab="ƽ������ (g)",
       par.settings=simpleTheme(pch=c(1:3),col=1),
       scales=list(x=list(at=seq(0,20,by=2))),
       type="p",col=c(2:4),auto.key=list(points=TRUE,lines=FALSE,space="top",columns=3))

kk=table(pup$dam,pup$gender)
fm=as.numeric(t(kk))

aa=aggregate(pup$weight,by=list(pup$dam,pup$dose,pup$gender),FUN=mean)
aa=as.data.frame(aa)
colnames(aa)=c("Dam","Dose","Sex","Weight")
aa$Dam=as.factor(aa$Dam)

aa=aa[order(aa$Dam),]

fm=fm[-24]
aa$fm=fm
aa=aa[order(aa$fm),]
xyplot(Weight~ fm|Dose, data=aa,groups=Sex,layout=c(1,3),ylim=c(min(aa$Weight)-0.5,max(aa$Weight)+0.5),
       xlab="ÿ��̥����Ŀ",ylab="ƽ������ (g)",par.settings=simpleTheme(pch=c(1:3),col=1),
       scales=list(x=list(at=seq(0,20,by=2))),
       type="b",auto.key=list(points=TRUE,lines=TRUE,space="top",columns=2))

###############################################
#Example 7 wages
##################################################
wage=as.data.frame(read.table(file="WAGES.csv",header = TRUE ,  sep = ","))[,1:13]
head(wage,20)
length(unique(wage$Sub))
table(wage$Sub)
length(wage[,1])
wage$FEM=as.factor(wage$FEM)
levels(wage$FEM)=c("����","Ů��")
wage$BLK=as.factor(wage$BLK)
levels(wage$BLK)=c("����","����")
head(wage[,1:13])

length(unique(wage$Sub))
library(lattice)
xyplot(LWAGE~WKS|FEM*BLK,groups=as.factor(wage$ED),data=wage,xlab="������ʱ��(week)",ylab="log(����)",type="p",col=1)
      

#xyplot(LWAGE~WKS|FEM*BLK,groups=as.factor(wage$ED),data=wage,xlab="������ʱ��(week)",ylab="log(����)",
       #pch=levels(as.factor(wage$ED)), auto.key=list(points=TRUE,pch=TRUE,space="top",columns=7))

xyplot(LWAGE~ED|FEM*BLK,xlab="���ܽ�����ʱ�䣨year��",ylab="log(����)", data=wage, type="p", col=1 )

###############################################
#Example 8 ������֧������
##################################################
###############################################################################
# Data_JAE_Browning_Collado                                                   #
#Martin Browning and M. Dolores Collado, "Habits and Heterogeneity in         #
#Demands: A Panel Data Analysis", Journal of Applied Econometrics,            #
#Vol. 22, Bo. 3, 2007, pp. 625-640.                                           #
###############################################################################
# Variable definition:
#There are 18 variables:
#
# 1. Number of interviews (it goes from 6 to 8).
# 2. Household identification number.
# 3. Interview number.
# 4. year
# 5. quarter
# 6. week
# 7. Number of children younger than 18.
# 8. Number of adults.
# 9. Husband's age.
#10. Total expenditure in pesetas.
#11. Husband earnings in pesetas.
#12. Stone price index.
#13. Food at home (budget share).
#14. Food out (budget share).
#15. Alcohol and tobacco (budget share).
#16. Non-durables and services (budget share).
#17. Clothing (budget share).
#18. Small durables (budget share).
###############################################################################

# Load data 
DataSet <- read.table( file="BrowningColladoData.txt",sep="", header=FALSE)

# Name the variables according to readme.bb.txt
colnames(DataSet)       <- c(
  "TotalInterviews",       # Number of interviews (it goes from 6 to 8).
  "HouseholdID",           # Household identification number.
  "InterviewNumber",       # Interview number.
  "Year",                  # year
  "Quarter",               # quarter
  "Week",                  # week
  "ChildrenBelow18",       # Number of children younger than 18.
  "AdultNumber",           # Number of adults.
  "HusbandAge",            # Husband's age.
  "TotalExpenditure",      # Total expenditure in pesetas.
  "HusbandEarning",        # Husband earnings in pesetas.
  "StonePriceIndex",       # Stone price index.
  "FoodAtHome",            # Food at home (budget share).
  "FoodOut",               # Food out (budget share).
  "AlcoholAndTobacco",     # Alcohol and tobacco (budget share).
  "NonDurableAndServices", # Non-durables and services (budget share).
  "Clothing",              # Clothing (budget share).
  "SmallDurables"          # Small durables (budget share).
)
head(DataSet,40)


# Generate summary statistics
SummaryStatisticsDataSet <- cbind(apply(DataSet,2,FUN="mean"),apply(DataSet,2,FUN="sd"))
colnames(SummaryStatisticsDataSet) <- c("mean","sd")
library(xtable)
xtable(SummaryStatisticsDataSet,digit=4)
m=length(unique(DataSet$HouseholdID))
M=length(DataSet[,1])

library(lattice)
xyplot(log(TotalExpenditure)~Year|as.factor(Quarter),
groups=as.factor(HouseholdID),data=DataSet,col=1,ylab="Log(��ͥ��֧��)",xlab="���")



###############################################
#example 9   Crime data
############################################
library(xtable)
crime <- read.table(file="crime4.txt",sep="",header=FALSE)

# Name the variables according to readme.bb.txt
colnames(crime) <- c(
  "county"  ,  "year"    ,  "crmrte"  ,  "prbarr"  ,  "prbconv" ,  "prbpris" ,  "avgsen"  , "polpc"  ,  
  "density" ,  "taxpc"   ,  "west"    ,  "central" ,  "urban"   ,  "pctmin80",  "wcon"    , "wtuc"   ,  
  "wtrd"    ,  "wfir"    ,  "wser"    ,  "wmfg"    ,  "wfed"    ,  "wsta"    ,  "wloc"    , "mix"    ,  
  "pctymle" ,  "d82"     ,  "d83"     ,  "d84"     ,  "d85"     ,  "d86"     ,  "d87"     , "lcrmrte",  
  "lprbarr" ,  "lprbconv",  "lprbpris",  "lavgsen" ,  "lpolpc"  ,  "ldensity",  "ltaxpc"  , "lwcon"  , 
  "lwtuc"   ,  "lwtrd"   ,  "lwfir"   ,  "lwser"   ,  "lwmfg"   ,  "lwfed"   ,  "lwsta"   , "lwloc"  ,  
  "lmix"    ,  "lpctymle",  "lpctmin" ,  "clcrmrte",  "clprbarr",  "clprbcon",  "clprbpri",  
  "clavgsen",  "clpolpc" ,  "cltaxpc" ,  "clmix"     
)

head(crime,20)
m=length(unique(crime$county))

# Remove rows with entry "."
#crime[(crime[,"clcrmrte"] == "."),"clcrmrte"]  <- NA
# Redeclare the variable as numeric variable
#crime[,"clcrmrte"] <- as.numeric(crime[,"clcrmrte"])

# Remove rows with entry "."
#crime[(crime[,"clprbarr"] == "."),"clprbarr"]  <- NA
# Redeclare the variable as numeric variable
#crime[,"clprbarr"] <- as.numeric(crime[,"clprbarr"])

# Remove rows with entry "."
#crime[(crime[,"clprbcon"] == "."),"clprbcon"]  <- NA
# Redeclare the variable as numeric variable
#crime[,"clprbcon"] <- as.numeric(crime[,"clprbcon"])

# Remove rows with entry "."
#crime[(crime[,"clprbpri"] == "."),"clprbpri"]  <- NA
# Redeclare the variable as numeric variable
#crime[,"clprbpri"] <- as.numeric(crime[,"clprbpri"])

# Remove rows with entry "."
#crime[(crime[,"clavgsen"] == "."),"clavgsen"]  <- NA
# Redeclare the variable as numeric variable
#crime[,"clavgsen"] <- as.numeric(crime[,"clavgsen"])

# Remove rows with entry "."
#crime[(crime[,"clpolpc"] == "."),"clpolpc"]  <- NA
# Redeclare the variable as numeric variable
#crime[,"clpolpc"] <- as.numeric(crime[,"clpolpc"])

# Remove rows with entry "."
#crime[(crime[,"cltaxpc"] == "."),"cltaxpc"]  <- NA
# Redeclare the variable as numeric variable
#crime[,"cltaxpc"] <- as.numeric(crime[,"cltaxpc"])

# Remove rows with entry "."
#crime[(crime[,"clmix"] == "."),"clmix"]  <- NA
# Redeclare the variable as numeric variable
#crime[,"clmix"] <- as.numeric(crime[,"clmix"])


#crime<- na.omit(crime)
crime$west=as.factor(crime$west)
levels(crime$west)=c("����","����")



png("Fig1.11.png", width = 5, height = 5, units = 'in', res = 500)
xyplot(crmrte~year|west,col=1,type="b",ylab="������", xlab="���/year",groups=as.factor(county), data=crime)

dev.off()
xyplot(crmrte~density,col=1,ylab="������", xlab="�˿��ܶ�",data=crime)



# Generate summary statistics
#SummaryStatisticsDataSet <- cbind(apply(crime,2,FUN="mean"),apply(crime,2,FUN="sd"))
#colnames(SummaryStatisticsDataSet) <- c("mean","sd")
#xtable(SummaryStatisticsDataSet,digit=4)