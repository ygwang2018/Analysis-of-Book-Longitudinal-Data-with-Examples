 
ar1 <- function(r,n)
{
 lags <- diag(n)
 lags<-abs(row(lags)-col(lags))
 r^lags
}

cs<- function(r,n)
{
lags<-matrix(1,n,n)-diag(1,n,n)
r^lags
}

tr<-function(a){
sum(diag(a))
}


# source("seize.R")



require(geepack)
require(yags)


## If Patient  207 not removed?  n<-59

n<-59

m<-4

###seize<-as.data.frame(matrix(scan("seize.txt"),232,6,byrow=T))

seize<-as.data.frame(matrix(scan("seize.all.txt"),236,6,byrow=T))

names(seize)=c("id", "y","Time","trt","base","age")

#attach(seize)

seize$age<-log(seize$age)
seize$base<-log(seize$base/4)
seize$intact<-seize$trt*seize$base



fit<-geese(y~base+age+trt+base:trt,id=id,sca.link="log",
 corstr="exchangeable",family=poisson,data=seize)


fit<-geese(y~base+age+trt+base:trt,id=id,sca.link="log",
 corstr="ar1",family=poisson,data=seize)

fit<-yags(y~base+age+trt+intact,id=id,corstr="ar1",cor.met=Time,
  alphainit=0,family=poisson,data=seize)

summary(fit)



########var1=poisson var2=bartlett var3=power

########################################## ar1

var1.b0<--2.614
var1.b1<-0.942
var1.b2<-0.849
var1.b3<--0.615
var1.b4<-0.171

var2.b0<--2.370
var2.b1<-0.939
var2.b2<-0.766
var2.b3<--0.560
var2.b4<-0.124

var3.b0<--2.395
var3.b1<-0.926
var3.b2<-0.758
var3.b3<--0.598
var3.b4<-0.104

var1.phi<-2.073
var2.phi1<-1.340
var2.phi2<-0.493
var3.phi1<-1.754
var3.phi2<-1.657

var1.corr<-ar1(0.448,4)
var2.corr<-ar1(0.461,4)
var3.corr<-ar1(0.45,4)

mu.var1<-exp(var1.b0+var1.b1*base+var1.b2*age+var1.b3*trt+var1.b4*base*trt)
mu.var2<-exp(var2.b0+var2.b1*base+var2.b2*age+var2.b3*trt+var2.b4*base*trt)
mu.var3<-exp(var3.b0+var3.b1*base+var3.b2*age+var3.b3*trt+var3.b4*base*trt)


var1<-function(a){
var1.phi*(mu.var1[a,])}

var2<-function(a){
var2.phi1*mu.var2[a,]+var2.phi2*(mu.var2[a,])^2}

var3<-function(a){
var3.phi1*(mu.var3[a,])^var3.phi2}

invcov.1<-function(a){
diag((var1(a))^(-1/2))%*%solve(var1.corr)%*%diag((var1(a))^(-1/2)) }

invcov.2<-function(a){
diag((var2(a))^(-1/2))%*%solve(var2.corr)%*%diag((var2(a))^(-1/2)) }

invcov.3<-function(a){
diag((var3(a))^(-1/2))%*%solve(var3.corr)%*%diag((var3(a))^(-1/2)) }

########### q0

D<-function(a){
a1<-rep(1,4)
a2<-base[a]
a3<-age[a]
a4<-trt[a]
a5<-intact[a]
a6<-rbind(a1,a2,a3,a4,a5)
return(a6)
}

Vopt1.1<-0
Vmid.1<-0

Vopt1.2<-0
Vmid.2<-0

Vopt1.3<-0
Vmid.3<-0

for( i in 1:n){
Vopt1.1<-Vopt1.1+D(i)%*%invcov.1(i)%*%t(D(i))
Vmid.1<-Vmid.1+D(i)%*%invcov.1(i)%*%((r[i,]-mu.var1[i,])%*%t(r[i,]-mu.var1[i,]))%*%invcov.1(i)%*%t(D(i))

Vopt1.2<-Vopt1.2+D(i)%*%invcov.2(i)%*%t(D(i))
Vmid.2<-Vmid.2+D(i)%*%invcov.2(i)%*%((r[i,]-mu.var2[i,])%*%t(r[i,]-mu.var2[i,]))%*%invcov.2(i)%*%t(D(i))

Vopt1.3<-Vopt1.3+D(i)%*%invcov.3(i)%*%t(D(i))
Vmid.3<-Vmid.3+D(i)%*%invcov.3(i)%*%((r[i,]-mu.var3[i,])%*%t(r[i,]-mu.var3[i,]))%*%invcov.3(i)%*%t(D(i))
}

Vopt.1<-solve(Vopt1.1)
Vrob.1<-Vopt.1%*%Vmid.1%*%Vopt.1

Vopt.2<-solve(Vopt1.2)
Vrob.2<-Vopt.2%*%Vmid.2%*%Vopt.2

Vopt.3<-solve(Vopt1.3)
Vrob.3<-Vopt.3%*%Vmid.3%*%Vopt.3

eig.1<-eigen(Vopt1.1%*%Vrob.1,only.values=T)$values
eig.2<-eigen(Vopt1.2%*%Vrob.2,only.values=T)$values
eig.3<-eigen(Vopt1.3%*%Vrob.3,only.values=T)$values

c1.1<-sum(eig.1)/5
c2.1<-sum(eig.1^2)/5
c1.2<-sum(eig.2)/5
c2.2<-sum(eig.2^2)/5
c1.3<-sum(eig.3)/5
c2.3<-sum(eig.3^2)/5

q00.ar1.1<-(c1.1-1)^2+(c2.1-1)^2
q01.ar1.1<-c2.1-2*c1.1+1
q02.ar1.1<-sum((log(eig.1))^2)

q00.ar1.2<-(c1.2-1)^2+(c2.2-1)^2
q01.ar1.2<-c2.2-2*c1.2+1
q02.ar1.2<-sum((log(eig.2))^2)

q00.ar1.3<-(c1.3-1)^2+(c2.3-1)^2
q01.ar1.3<-c2.3-2*c1.3+1
q02.ar1.3<-sum((log(eig.3))^2)


########## q2

q20.ar1.1<-0
q20.ar1.2<-0
q20.ar1.3<-0

for( i in 1:n){
q20.ar1.1<-q20.ar1.1+(r[i,]-mu.var1[i,])%*%invcov.1(i)%*%(r[i,]-mu.var1[i,])+log(det(var1.corr))+sum(log(var1(i)))
q20.ar1.2<-q20.ar1.2+(r[i,]-mu.var2[i,])%*%invcov.2(i)%*%(r[i,]-mu.var2[i,])+log(det(var2.corr))+sum(log(var2(i)))
q20.ar1.3<-q20.ar1.3+(r[i,]-mu.var3[i,])%*%invcov.3(i)%*%(r[i,]-mu.var3[i,])+log(det(var3.corr))+sum(log(var3(i)))
}

q21.ar1.1<-q20.ar1.1-2*log(det(Vopt1.1))+log(det(Vmid.1))
q21.ar1.2<-q20.ar1.2-2*log(det(Vopt1.2))+log(det(Vmid.2))
q21.ar1.3<-q20.ar1.3-2*log(det(Vopt1.3))+log(det(Vmid.3))

######### QIC

q3.mbv.1<-0
q3.mbv.2<-0
q3.mbv.3<-0

for( i in 1:n){
q3.mbv.1<-q3.mbv.1+D(i)%*%diag(var1(i)^(-1))%*%t(D(i))
q3.mbv.2<-q3.mbv.2+D(i)%*%diag(var2(i)^(-1))%*%t(D(i))
q3.mbv.3<-q3.mbv.3+D(i)%*%diag(var3(i)^(-1))%*%t(D(i))
}
 

if(prod(r)!=0) {
q30.ar1.1<--2/var1.phi*sum(r*log(mu.var1)-mu.var1-r*log(r)+r)+2*tr(q3.mbv.1%*%Vrob.1)
q30.ar1.2<--2*sum(r*log(mu.var2)/var2.phi1-(var2.phi1+var2.phi2*r)/(var2.phi1*var2.phi2)*log(mu.var2+var2.phi1/var2.phi2)-r*log(r)/var2.phi1+(var2.phi1+var2.phi2*r)/(var2.phi1*var2.phi2)*log(r+var2.phi1/var2.phi2))+2*tr(q3.mbv.2%*%Vrob.2)
}

if(prod(r)==0) {
q30.ar1.1<-0 
q30.ar1.2<-0
for( i in 1:n){
for( j in 1:m){
if (r[i,j]==0){  
q30.ar1.1<-q30.ar1.1+2/var1.phi*(mu.var1[i,j])
q30.ar1.2<-q30.ar1.2-2*(-log(mu.var2[i,j]+var2.phi1/var2.phi2)/var2.phi2+1/var2.phi2*log(var2.phi1/var2.phi2))
}

if (r[i,j]!=0){
q30.ar1.1<-q30.ar1.1-2/var1.phi*(r[i,j]*log(mu.var1[i,j])-mu.var1[i,j]-r[i,j]*log(r[i,j])+r[i,j])
q30.ar1.2<-q30.ar1.2-2*(r[i,j]*log(mu.var2[i,j])/var2.phi1-(var2.phi1+var2.phi2*r[i,j])/(var2.phi1*var2.phi2)*log(mu.var2[i,j]+var2.phi1/var2.phi2)-r[i,j]*log(r[i,j])/var2.phi1+(var2.phi1+var2.phi2*r[i,j])/(var2.phi1*var2.phi2)*log(r[i,j]+var2.phi1/var2.phi2))
}
}
}
}

q30.ar1.1<-q30.ar1.1+2*tr(q3.mbv.1%*%Vrob.1)
q30.ar1.2<-q30.ar1.2+2*tr(q3.mbv.2%*%Vrob.2)
q30.ar1.3<--2/var3.phi1*sum(r*mu.var3^(1-var3.phi2)/(1-var3.phi2)-mu.var3^(2-var3.phi2)/(2-var3.phi2)-r^(2-var3.phi2)/(1-var3.phi2)+r^(2-var3.phi2)/(2-var3.phi2))+2*tr(q3.mbv.3%*%Vrob.3)

q31.ar1.1<-2*tr(q3.mbv.1%*%Vrob.1)
q31.ar1.2<-2*tr(q3.mbv.2%*%Vrob.2)
q31.ar1.3<-2*tr(q3.mbv.3%*%Vrob.3)


########################################## exchangeable

var1.b0<--2.362
var1.b1<-0.95
var1.b2<-0.769
var1.b3<--0.522
var1.b4<-0.138

var2.b0<--2.355
var2.b1<-0.946
var2.b2<-0.769
var2.b3<--0.518
var2.b4<-0.142

var3.b0<--2.359
var3.b1<-0.943
var3.b2<-0.768
var3.b3<--0.531
var3.b4<-0.135

var1.phi<-2.058
var2.phi1<-1.202
var2.phi2<-0.420
var3.phi1<-1.269
var3.phi2<-1.655

var1.corr<-cs(0.328,4)
var2.corr<-cs(0.338,4)
var3.corr<-cs(0.332,4)

mu.var1<-exp(var1.b0+var1.b1*base+var1.b2*age+var1.b3*trt+var1.b4*base*trt)
mu.var2<-exp(var2.b0+var2.b1*base+var2.b2*age+var2.b3*trt+var2.b4*base*trt)
mu.var3<-exp(var3.b0+var3.b1*base+var3.b2*age+var3.b3*trt+var3.b4*base*trt)


var1<-function(a){
var1.phi*(mu.var1[a,])}

var2<-function(a){
var2.phi1*mu.var2[a,]+var2.phi2*(mu.var2[a,])^2}

var3<-function(a){
var3.phi1*(mu.var3[a,])^var3.phi2}

invcov.1<-function(a){
diag((var1(a))^(-1/2))%*%solve(var1.corr)%*%diag((var1(a))^(-1/2)) }

invcov.2<-function(a){
diag((var2(a))^(-1/2))%*%solve(var2.corr)%*%diag((var2(a))^(-1/2)) }

invcov.3<-function(a){
diag((var3(a))^(-1/2))%*%solve(var3.corr)%*%diag((var3(a))^(-1/2)) }

########### q0

Vopt1.1<-0
Vmid.1<-0

Vopt1.2<-0
Vmid.2<-0

Vopt1.3<-0
Vmid.3<-0

for( i in 1:n){
Vopt1.1<-Vopt1.1+D(i)%*%invcov.1(i)%*%t(D(i))
Vmid.1<-Vmid.1+D(i)%*%invcov.1(i)%*%((r[i,]-mu.var1[i,])%*%t(r[i,]-mu.var1[i,]))%*%invcov.1(i)%*%t(D(i))

Vopt1.2<-Vopt1.2+D(i)%*%invcov.2(i)%*%t(D(i))
Vmid.2<-Vmid.2+D(i)%*%invcov.2(i)%*%((r[i,]-mu.var2[i,])%*%t(r[i,]-mu.var2[i,]))%*%invcov.2(i)%*%t(D(i))

Vopt1.3<-Vopt1.3+D(i)%*%invcov.3(i)%*%t(D(i))
Vmid.3<-Vmid.3+D(i)%*%invcov.3(i)%*%((r[i,]-mu.var3[i,])%*%t(r[i,]-mu.var3[i,]))%*%invcov.3(i)%*%t(D(i))
}

Vopt.1<-solve(Vopt1.1)
Vrob.1<-Vopt.1%*%Vmid.1%*%Vopt.1

Vopt.2<-solve(Vopt1.2)
Vrob.2<-Vopt.2%*%Vmid.2%*%Vopt.2

Vopt.3<-solve(Vopt1.3)
Vrob.3<-Vopt.3%*%Vmid.3%*%Vopt.3

eig.1<-eigen(Vopt1.1%*%Vrob.1,only.values=T)$values
eig.2<-eigen(Vopt1.2%*%Vrob.2,only.values=T)$values
eig.3<-eigen(Vopt1.3%*%Vrob.3,only.values=T)$values

c1.1<-sum(eig.1)/5
c2.1<-sum(eig.1^2)/5
c1.2<-sum(eig.2)/5
c2.2<-sum(eig.2^2)/5
c1.3<-sum(eig.3)/5
c2.3<-sum(eig.3^2)/5

q00.cs.1<-(c1.1-1)^2+(c2.1-1)^2
q01.cs.1<-c2.1-2*c1.1+1
q02.cs.1<-sum((log(eig.1))^2)

q00.cs.2<-(c1.2-1)^2+(c2.2-1)^2
q01.cs.2<-c2.2-2*c1.2+1
q02.cs.2<-sum((log(eig.2))^2)

q00.cs.3<-(c1.3-1)^2+(c2.3-1)^2
q01.cs.3<-c2.3-2*c1.3+1
q02.cs.3<-sum((log(eig.3))^2)


########## q2

q20.cs.1<-0
q20.cs.2<-0
q20.cs.3<-0

for( i in 1:n){
q20.cs.1<-q20.cs.1+(r[i,]-mu.var1[i,])%*%invcov.1(i)%*%(r[i,]-mu.var1[i,])+log(det(var1.corr))+sum(log(var1(i)))
q20.cs.2<-q20.cs.2+(r[i,]-mu.var2[i,])%*%invcov.2(i)%*%(r[i,]-mu.var2[i,])+log(det(var2.corr))+sum(log(var2(i)))
q20.cs.3<-q20.cs.3+(r[i,]-mu.var3[i,])%*%invcov.3(i)%*%(r[i,]-mu.var3[i,])+log(det(var3.corr))+sum(log(var3(i)))
}

q21.cs.1<-q20.cs.1-2*log(det(Vopt1.1))+log(det(Vmid.1))
q21.cs.2<-q20.cs.2-2*log(det(Vopt1.2))+log(det(Vmid.2))
q21.cs.3<-q20.cs.3-2*log(det(Vopt1.3))+log(det(Vmid.3))

######### QIC

q3.mbv.1<-0
q3.mbv.2<-0
q3.mbv.3<-0

for( i in 1:n){
q3.mbv.1<-q3.mbv.1+D(i)%*%diag(var1(i)^(-1))%*%t(D(i))
q3.mbv.2<-q3.mbv.2+D(i)%*%diag(var2(i)^(-1))%*%t(D(i))
q3.mbv.3<-q3.mbv.3+D(i)%*%diag(var3(i)^(-1))%*%t(D(i))
}

if(prod(r)!=0) {
q30.cs.1<--2/var1.phi*sum(r*log(mu.var1)-mu.var1-r*log(r)+r)+2*tr(q3.mbv.1%*%Vrob.1)
q30.cs.2<--2*sum(r*log(mu.var2)/var2.phi1-(var2.phi1+var2.phi2*r)/(var2.phi1*var2.phi2)*log(mu.var2+var2.phi1/var2.phi2)-r*log(r)/var2.phi1+(var2.phi1+var2.phi2*r)/(var2.phi1*var2.phi2)*log(r+var2.phi1/var2.phi2))+2*tr(q3.mbv.2%*%Vrob.2)
}

if(prod(r)==0) {
q30.cs.1<-0 
q30.cs.2<-0
for( i in 1:n){
for( j in 1:m){
if (r[i,j]==0){  
q30.cs.1<-q30.cs.1+2/var1.phi*(mu.var1[i,j])
q30.cs.2<-q30.cs.2-2*(-log(mu.var2[i,j]+var2.phi1/var2.phi2)/var2.phi2+1/var2.phi2*log(var2.phi1/var2.phi2))
}

if (r[i,j]!=0){
q30.cs.1<-q30.cs.1-2/var1.phi*(r[i,j]*log(mu.var1[i,j])-mu.var1[i,j]-r[i,j]*log(r[i,j])+r[i,j])
q30.cs.2<-q30.cs.2-2*(r[i,j]*log(mu.var2[i,j])/var2.phi1-(var2.phi1+var2.phi2*r[i,j])/(var2.phi1*var2.phi2)*log(mu.var2[i,j]+var2.phi1/var2.phi2)-r[i,j]*log(r[i,j])/var2.phi1+(var2.phi1+var2.phi2*r[i,j])/(var2.phi1*var2.phi2)*log(r[i,j]+var2.phi1/var2.phi2))
}
}
}
}

q30.cs.1<-q30.cs.1+2*tr(q3.mbv.1%*%Vrob.1)
q30.cs.2<-q30.cs.2+2*tr(q3.mbv.2%*%Vrob.2)
q30.cs.3<--2/var3.phi1*sum(r*mu.var3^(1-var3.phi2)/(1-var3.phi2)-mu.var3^(2-var3.phi2)/(2-var3.phi2)-r^(2-var3.phi2)/(1-var3.phi2)+r^(2-var3.phi2)/(2-var3.phi2))+2*tr(q3.mbv.3%*%Vrob.3)

q31.cs.1<-2*tr(q3.mbv.1%*%Vrob.1)
q31.cs.2<-2*tr(q3.mbv.2%*%Vrob.2)
q31.cs.3<-2*tr(q3.mbv.3%*%Vrob.3)



cat("**********q00**************","\n")
cat("q00.ar1.1=",q00.ar1.1,"\n")
cat("q00.ar1.2=",q00.ar1.2,"\n")
cat("q00.ar1.3=",q00.ar1.3,"\n")
cat("q00.cs.1=",q00.cs.1,"\n")
cat("q00.cs.2=",q00.cs.2,"\n")
cat("q00.cs.3=",q00.cs.3,"\n")

cat("**********q01**************","\n")
cat("q01.ar1.1=",q01.ar1.1,"\n")
cat("q01.ar1.2=",q01.ar1.2,"\n")
cat("q01.ar1.3=",q01.ar1.3,"\n")
cat("q01.cs.1=",q01.cs.1,"\n")
cat("q01.cs.2=",q01.cs.2,"\n")
cat("q01.cs.3=",q01.cs.3,"\n")

cat("**********q02**************","\n")
cat("q02.ar1.1=",q02.ar1.1,"\n")
cat("q02.ar1.2=",q02.ar1.2,"\n")
cat("q02.ar1.3=",q02.ar1.3,"\n")
cat("q02.cs.1=",q02.cs.1,"\n")
cat("q02.cs.2=",q02.cs.2,"\n")
cat("q02.cs.3=",q02.cs.3,"\n")

cat("**********q20**************","\n")
cat("q20.ar1.1=",q20.ar1.1,"\n")
cat("q20.ar1.2=",q20.ar1.2,"\n")
cat("q20.ar1.3=",q20.ar1.3,"\n")
cat("q20.cs.1=",q20.cs.1,"\n")
cat("q20.cs.2=",q20.cs.2,"\n")
cat("q20.cs.3=",q20.cs.3,"\n")

cat("**********q21**************","\n")
cat("q21.ar1.1=",q21.ar1.1,"\n")
cat("q21.ar1.2=",q21.ar1.2,"\n")
cat("q21.ar1.3=",q21.ar1.3,"\n")
cat("q21.cs.1=",q21.cs.1,"\n")
cat("q21.cs.2=",q21.cs.2,"\n")
cat("q21.cs.3=",q21.cs.3,"\n")

cat("**********q30**************","\n")
cat("q30.ar1.1=",q30.ar1.1,"\n")
cat("q30.ar1.2=",q30.ar1.2,"\n")
cat("q30.ar1.3=",q30.ar1.3,"\n")
cat("q30.cs.1=",q30.cs.1,"\n")
cat("q30.cs.2=",q30.cs.2,"\n")
cat("q30.cs.3=",q30.cs.3,"\n")


cat("**********q31**************","\n")
cat("q31.ar1.1=",q31.ar1.1,"\n")
cat("q31.ar1.2=",q31.ar1.2,"\n")
cat("q31.ar1.3=",q31.ar1.3,"\n")
cat("q31.cs.1=",q31.cs.1,"\n")
cat("q31.cs.2=",q31.cs.2,"\n")
cat("q31.cs.3=",q31.cs.3,"\n")