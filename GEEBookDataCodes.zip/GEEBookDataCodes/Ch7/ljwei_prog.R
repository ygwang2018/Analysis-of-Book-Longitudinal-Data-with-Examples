#return values: par_jy is estimated parameter using J&Y method, par_wr is estimated parameter using weighted rank reg.
####            U_JY is the E.F value of J&Y, U_wr is teh E.F value of weighted rank reg. 
####            Cov_JY is the covarince matrix of sqrt(N)*(U_J&Y), Cov_wr is the covariance matrix of sqrt(N)*(U_weighted)


data=read.table("D:\\Onlyme\\Rank\\Wang\\1.23wang\\exm\\ljwei\\ljw\\ljwei.txt",header=T,sep="\t")
ALL=data
###############################################################################
rreg=function(ALL){


	temp=na.omit(ALL)

#temp=temp[1:(dim(temp)[1]-5),]

	Time=temp$time; Treat=temp$trt
	T1=T2=T3=rep(0,length(Time))
for(i in 1:length(Time)){
	if(Time[i]==6){
		T1[i]=0;T2[i]=0;T3[i]=0
	}
	if(Time[i]==12){
		T1[i]=1;T2[i]=0;T3[i]=0
	}
	if(Time[i]==20){
		T1[i]=0;T2[i]=1;T3[i]=0
	}
	if(Time[i]==24){
		T1[i]=0;T2[i]=0;T3[i]=1
	}
}
	x=cbind(T1,T2,T3,Treat)
	ss=length(x[,1])
	id=temp$id
	idd=as.vector(abs(outer(id,id,"-")))
	sub.no=length(levels(factor(id)))
	y=temp$y
#######increase next mean profile########################
#for(i in 1:(sub.no-2)){
#	cs=length(y[id==i])
#	temp5=rep(0,(cs+1))
#	temp6=rep(0,cs)
#	temp5=c(0,y[id==i])
#	for(j in 1:cs) temp6[j]=temp5[j+1]-temp5[j]
#	y[id==i]=temp6
#}
##########################################################
	

m_pla=m_trt=NULL
tlevel=as.numeric(names(summary(as.factor(Time))))
for(i in tlevel) m_pla=c(m_pla,mean(y[Treat==0&Time==i]))
for(i in tlevel) m_trt=c(m_trt,mean(y[Treat==1&Time==i]))

plot(tlevel,m_pla,type="l",ylim=c(min(c(m_pla,m_trt)),max(c(m_pla,m_trt))),ylab="Mean Increase",xlab="Month of Treatment",lty=2)
points(tlevel,m_trt,type="l",lty=1)
legend(20,10,c("Treatment","Placebo"),lty=1:2,cex=0.8)

###############################################################################
D=function(beta){
	e=y-x%*%beta
	obj=(rank(e)-(ss+1)/2)%*%e
	obj
	}

D1=function(beta){
		obj=0
		e=(y-x%*%beta)
		obj=as.vector(outer(w,w,"*"))*as.vector(abs(outer(e,e,"-")))
            	obj<-sum(obj[idd>0])
		obj
	}
###############################################################################


temp1=rep(1,ss); temp2=rep(0,max(id))

for(i in 1:max(id))   temp2[i]=sum(temp1[id==i])
validn=temp2[temp2>0]
################################################################################

print(table(validn))
result0=optim(rep(0,dim(x)[2]),D,control=list(reltol=1e-05))$par

##estimate rho using moment method############################################## 
weight=function(result){		
      estar=y-x%*%result
      location=median(y-x%*%result)
      e0=estar-location 
      er=rank(e0)-(sum(validn)+1)/2		
      idw=abs(outer(id,id,"-"))
      diag(idw)<-1
      idw<-as.vector(idw)
      perr=outer(er,er,"*")
      numer=sum(as.vector(perr)[idw==0])
      denom=as.numeric(rep(validn-1,validn)%*%(er^2))
      rho_mom=abs(numer/denom)
      w=rep(1/(1+rho_mom*(validn-1)),validn)
      list(w=w,rho_mom=rho_mom)	
}	
###############################################################################
cat("rho_mom=",weight(result0)$rho_mom,"\n")
w=weight(result0)$w 

result1=optim(result0,D1,control=list(reltol=1e-05))$par

#####cov of E.F################################################################
cov_u=function(result,wgt){
	resi=y-x%*%result
	nco=dim(x)[2]
	eta=matrix(0,nr=sub.no,nc=nco)
		for (i in 1:sub.no){
			for(j in 1:sub.no){	
			    if(j==i) next
			    eoe=outer(resi[id==i],resi[id==j],">")-1/2
			    xi=matrix(x[id==i],nc=nco)
			    xj=matrix(x[id==j],nc=nco)
			    xik=xjl=rep(0,nco)	
			    for(k in 1:validn[i]) xik=xik+xi[k,]*sum(eoe[k,])
			    for(l in 1:validn[j]) xjl=xjl+xj[l,]*sum(eoe[,l])
			    eta[i,]=eta[i,]+wgt[id==i][1]*wgt[id==j][1]*(xik-xjl)	
			}		
		}
	temp3=matrix(0,nr=nco,nc=nco)
	for(i in 1:sub.no) temp3=temp3+eta[i,]%o%eta[i,]
	varu=16*temp3/(ss^3)
	varu
        #cat("The asymptotic covariance matrix of E.F","\n",varu)
	list(covu=varu)
}

######value of E.F##################################################################

u_value=function(beta,wgt){
	sgn=function(x,y){
		sign(x-y)
    	}	
	resi=y-x%*%beta
	nco=dim(x)[2]
	ui=matrix(0,nr=sub.no,nc=nco)
		for (i in 1:sub.no){
			for(j in 1:sub.no){	
			    if(j==i) next
			    eoe=outer(resi[id==i],resi[id==j],"sgn")
			    xi=matrix(x[id==i],nc=nco)
			    xj=matrix(x[id==j],nc=nco)
			    xik=xjl=rep(0,nco)	
			    for(k in 1:validn[i]) xik=xik+xi[k,]*sum(eoe[k,])
			    #for(l in 1:validn[j]) xjl=xjl+xj[l,]*sum(eoe[,l])
			    #ui[i,]=ui[i,]+wgt[id==i][1]*wgt[id==j][1]*(xik-xjl)	
			    ui[i,]=ui[i,]+wgt[id==i][1]*wgt[id==j][1]*(xik)
			}		
		}
u=2*apply(ui,2,"sum")/(ss^2)
list(u=u)
}
######test###############################################################
wjy=rep(1,ss)
ujy=u_value(result0,wjy)$u
uwr=u_value(result1,w)$u
cjy=cov_u(result0,wjy)$covu
cwr=cov_u(result1,w)$covu

x_mtx=x
parno=dim(x_mtx)[2]

ujy_u=function(beta){
	obj=matrix(0,nc=parno,nr=ss)
	e=y-x%*%beta
	re=rank(e)
	for(i in 1:ss)	obj[i,]=(re[i]-(ss+1)/2)*x[i,]
	4*apply(obj,2,"sum")/(ss^2)
	}


uvujy=function(bi){
		ball=rep(0,parno)
		ball[-i]=bi; ball[i]=0
#		cjyit=cov_u(ball,wjy)$covu
		ujyt=ujy_u(ball)
		ss*(ujyt%*%solve(cjy)%*%ujyt)
	}


uvuwr=function(bi){
		ballr=rep(0,parno)
		ballr[-i]=bi; ballr[i]=0
#		w=weight(ballr)$w
#		cwrit=cov_u(ballr,w)$covu
		uwrt=u_value(ballr,w)$u
		ss*(uwrt%*%solve(cwr)%*%uwrt)
	}
for(i in 1:parno){
Chi_JY1=optim(result0[-i],uvujy)$value
Chi_wr1=optim(result1[-i],uvuwr)$value

#red_varjy=matrix(0,nc=dim(x)[2],nr=dim(x)[2])
#red_varjy[-i,-i]=solve(cjy[-i,-i])
#red_varwr=matrix(0,nc=dim(x)[2],nr=dim(x)[2])
#red_varwr[-i,-i]=solve(cwr[-i,-i])
#ujyt=u_value(parvec,wjy)$u
#uwrt=u_value(parvecwr,w)$u
#
#Chi_JY1=ss*(ujyt%*%solve(cjy)%*%ujyt-ujyt%*%red_varjy%*%ujyt)
cat("Chisq test for beta",i,"using J&Y:","\n",Chi_JY1,"\n")
#Chi_wr1=ss*(uwrt%*%solve(cwr)%*%uwrt-uwrt%*%red_varwr%*%uwrt)
cat("Chisq test for beta",i,"using Weighted rank reg.:","\n",Chi_wr1,"\n")
}




return(list(par_jy=result0,par_wr=result1,U_JY=ujy,U_wr=uwr,Cov_JY=cjy,Cov_wr=cwr))

}
rreg(data)

########Cov of parameters########
w1=rep(1/validn,validn)
U2=function(bb){
	d=rep(0,dim(x)[2]);obj=0
	ee=y-x%*%bb
	for (i in 1:sub.no){
	for(j in 1:sub.no){	
		if(j==i) next
		    xi=matrix(x[id==i],nc=nco)
		    xj=matrix(x[id==j],nc=nco)
			
		    for(k in 1:validn[i]){ 
		         for(l in 1:validn[j]){
				 b=c=0
				 b=sqrt((xi[k,]-xj[l,])%*%Gamma%*%(xi[k,]-xj[l,]))
				 #if(b==0){c=1;ib=1} else{
				 if(b==0)next	
				 c=(ee[id==i][k]-ee[id==j][l])/b
				 ib=1/b
				 #}
		    	     	 d=d+as.numeric(w[id==i][1]*w[id==j][1])*(xi[k,]-xj[l,])*(2*pnorm(c)-1)
			 }    
				
		    }
	}
}	
list(obj=d/ss^2)
}
nco=dim(x)[2]

Gamma=matrix(0,nc=nco,nr=nco)
diag(Gamma)=1
Gamma=Gamma
T=Gamma+1
itn=0
while(max(abs((Gamma-T)/Gamma))>0.001){
	
d=0
bb=result1
nb=result1+1
while(max(nb-bb)>0.001){
ee=y-x%*%bb
for (i in 1:sub.no){
	for(j in 1:sub.no){	
		if(j==i) next
		    xi=matrix(x[id==i],nc=nco)
		    xj=matrix(x[id==j],nc=nco)
			
		    for(k in 1:validn[i]){ 
		         for(l in 1:validn[j]){
				 b=c=0
				 b=sqrt((xi[k,]-xj[l,])%*%Gamma%*%(xi[k,]-xj[l,]))
				 #if(b==0){c=1;ib=1} else{
				 if(b==0)next	
				 c=(ee[id==i][k]-ee[id==j][l])/b
				 ib=1/b
				 #}
		    	     	 d=d+as.numeric(w[id==i][1]*w[id==j][1]*dnorm(c)*ib)*((xi[k,]-xj[l,])%o%(xi[k,]-xj[l,]))
			 }    
				
		    }
	}
}	
d=2*d/ss^2


bb=nb
nb=bb+solve(d)%*%U2(bb)$obj
cat(nb,"\n")
}
itn=itn+1
cat("# iteration","\t",itn,"\n")
T=Gamma
Gamma=(solve(d)%*%cwr%*%solve(d))/ss
print(Gamma)
}
lambda=Gamma
lambda

	

[1,] 0.285869577 0.05840377 0.03046662 0.007935756
[2,] 0.058403774 0.33928021 0.13615412 0.051579769
[3,] 0.030466615 0.13615412 0.53667990 0.024471709
[4,] 0.007935756 0.05157977 0.02447171 0.929035569

3.142287 13.313616  7.750847 10.392511