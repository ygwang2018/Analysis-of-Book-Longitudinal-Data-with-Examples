
library(lattice)

pup=read.table(file="pupweights.txt",header=T)


summary(pup)
table(pup$dam)
table(pup$dam,pup$gender)

M=length(pup[,1])
N=length(unique(pup$dam))
ni=as.numeric(table(pup$dam))

kk=table(pup$dam,pup$gender)
fm=as.numeric(t(kk))


 pup$size=rep(ni,times=ni)

dd=aggregate(pup$weight,by=list(pup$dam,pup$dose),FUN=mean)
dd=as.data.frame(dd)
colnames(dd)=c("Dam","Does","Weight")
dd$Dam=as.factor(dd$Dam)

dd=dd[order(dd$Dam),]
dd$ni=ni
xyplot(Weight~ ni, data=dd,groups=Does, xlab="Litter size",ylab="Mean weight",
par.settings=simpleTheme(pch=c(1:3),col=c(1,1,1)),
scales=list(x=list(at=seq(0,20,by=2))),
type="p",auto.key=list(points=TRUE,lines=FALSE,space="top",columns=3))

savePlot(file="meanweight.pdf",type="pdf")


aa=aggregate(pup$weight,by=list(pup$dam,pup$dose,pup$gender),FUN=mean)
aa=as.data.frame(aa)
colnames(aa)=c("Dam","Dose","Sex","Weight")
aa$Dam=as.factor(aa$Dam)

aa=aa[order(aa$Dam),]

fm=fm[-24]
aa$fm=fm
aa=aa[order(aa$fm),]
xyplot(Weight~ fm|Dose, data=aa,groups=Sex,layout=c(1,3),ylim=c(min(aa$Weight)-0.5,max(aa$Weight)+0.5),
xlab="Litter size",ylab="Mean weight",par.settings=simpleTheme(pch=c(1:3),col=c(1,1,1)),
scales=list(x=list(at=seq(0,20,by=2))),
type="b",auto.key=list(points=TRUE,lines=TRUE,space="top",columns=2))
savePlot(file="genderweight.pdf",type="pdf")




xyplot(Weight~ fm|Sex, data=aa,groups=Dose,ylim=c(min(aa$Weight)-0.5,max(aa$Weight)+0.5),
xlab="Litter size",ylab="Mean weight",par.settings=simpleTheme(pch=c(1:2),col=c(1,1)),
scales=list(x=list(at=seq(0,20,by=2))),
type="b",auto.key=list(points=TRUE,lines=TRUE,space="top",columns=3))
savePlot(file="doseweight.pdf",type="pdf")

  male=aa[(aa$Sex=="male"),]
  female=aa[(aa$Sex=="female"),]
  mc=male[male$Dose=="control",]
  ml=male[male$Dose=="low",]
  mh=male[male$Dose=="high",]

  mfc=female[female$Dose=="control",]
  mfl=female[female$Dose=="low",]
  mfh=female[female$Dose=="high",]
  plot(aa$fm,aa$Weight,ylim=c(min(aa$Weight)-0.5,max(aa$Weight)+0.5),type="n",xlab="Litter size",ylab="Mean weight")
  points(mc$fm,mc$Weight,col=1,pch=1,type="b")
  points(ml$fm,ml$Weight,col=1,pch=2,type="b")
  points(mh$fm,mh$Weight,col=1,pch=3,type="b")
  points(mfc$fm,mfc$Weight,col=2,pch=1,type="b")
  points(mfl$fm,mfl$Weight,col=2,pch=2,type="b")
  points(mfh$fm,mfh$Weight,col=2,pch=3,type="b")

  bwplot(dam~weight,data=pup)
  savePlot(file="boxplot.pdf",type="pdf")

  plot(density(pup$weight))
  qqnorm(pup$weight)
  qqline(pup$weight)

  savePlot(file="qqplot.pdf",type="pdf")