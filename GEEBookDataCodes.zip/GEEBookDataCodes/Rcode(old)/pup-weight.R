require(MASS)
require(mvtnorm)
require(abind)
require(magic)
require(Rlab)
library(lattice)
library(nlme)

source("rankfunction.R")
Z1=Sys.time()


pup=read.table(file="pupweights.txt",header=T)
summary(pup)
table(pup$dam)
table(pup$dam,pup$gender)
M=length(pup[,1])
N=length(unique(pup$dam))
ni=as.numeric(table(pup$dam))
kk=table(pup$dam,pup$gender)
fm=as.numeric(t(kk))
di=as.numeric(table(pup$dose))
 L=rep(c(0,1,0),times=c(di[1],di[3],di[2]))
 H=rep(c(0,0,1),times=c(di[1],di[3],di[2]))
 G= rep(rep(c(0,1),N),times=c(t(cbind(kk[,2],kk[,1]))))
 pup$L=L
 pup$H=H
 pup$G=G
 pup$size=rep(ni,times=ni)
 


M=sum(ni)
M2=sum(ni^2)
M3=sum(ni^3)
M4=sum(ni^4)

n0=rep(0,M)
nn=rep(ni,times=ni)
n0i=outer(n0,nn,"+")
ni1=nn-1
ni10=outer(ni1,n0,"+")
mni=rep(M-ni,times=ni)
mni0=outer(mni,n0,"+")
nii1=rep(ni*(ni-1),times=ni)
nii10=outer(nii1,n0,"+")
nni=outer((M-nn),nn,"-")

d22=matrix(1,nrow=ni[1])
for (i in 1:(N-1)) {
d22=adiag(d22,matrix(1,nrow=ni[i+1]))
  }

############################
#
#############################
a1=(M-ni)
a2= M2-ni^2
a12=a1^2-a2
a21=a2-a1
############################
#for  correlation coefficients
############################
d11=(M3-3*M2+2*M)
dd2=(M4-6*M3+11*M2-6*M)
d33=(M2*(1+M)-M3-M^2)
d44=2*M^2-(3*M+2)*M2+(3+M)*M3-M4
d55=(1+M)*M2-M3-M^2
d66=M^2-(2*M+1-M2)*M2+2*M3-M4
d77=M^3+2*M3-3*M*M2
d88=2*M4-M^3-2*(M+1)*M3+ (M^2+3*M-M2)*M2

p1=p2=0.5
p11=p1^2
p12=p1*p2
p22=p2^2

  sigma11=p1*(1-p1)
  sigma22=p2*(1-p2)
  sigma1=sqrt(sigma11 )
  sigma2=sqrt(sigma22)
  sigma12=sigma1*sigma2

  rho1=rho7=1/3
  rho2=rho4=0


id=rep(c(1:N),times=ni)
dx=abs(outer(id,id,"-"))
mlm=lm(weight~dose+gender+size+dose*gender,data=pup)
summary(mlm)
betalm=mlm$coef[-1]
betalme=lme(weight~gender+size+dose*gender,data=pup, random=~1|dose)



 
x=as.matrix(pup[,c(5:8)])
y=pup$weight
p=dim(x)[2]
 mlm=lm(weight~L+H+G+size,data=pup)
summary(mlm)
betalm=mlm$coef[-1]
betaI=optim(betalm,rankjy)$par
nlm(rankjy,p=rep(0,p))

  XX=array(0,dim=c(M,M,p))
  Dij=NULL
 for(i in 1:p){

 XX[,,i]=outer(x[,i],x[,i],"-")
dij=colSums(XX[,,i])/M
 Dij=rbind(Dij,dij)
 }



beta22=beta33=betaI


index<-0
iter<-1
while(iter<=10)
{

##########################################################
#  estimate sigma_1, sigma_2 and (rho_k,k=0,...,8)
# eight types of correlation coefficients
##########################################################


beta2=beta22
rhoop=rhof(beta2)
digVop=digVf(rhoop)
covop=covf(rhoop)
Vop=t(covop)+digVop+covop
beta22=optim(beta2,rankop)$par

beta3=beta33
rhojy3=rhof(beta3)
IdigV=IdigVf(rhojy3)
beta33=optim(beta3,rankjy3)$par

   print(cbind(beta33,beta22))
if(max(abs(beta2-beta22),abs(beta3-beta33))<=10^(-4)){index=1;break}
       else{iter<-iter+1}

       }
       print(iter)
    betaO=beta22
betaB=beta33
 print(cbind(betaI,betaB,betaO))


nsim<-200		
resb<-resjy<-matrix(NA,nc=p,nr=nsim)

for (i in 1:nsim)
{
	w<-rgamma(N,1,1)
	w<-rep(w,times=ni)
	wij<-outer(w,w,"*")
	resjy[i,]<-optim(betaI,Rankjyw)$par

 index<-0
iter<-1
bit=obj=NULL

 beta33=betaI
while(iter<=7)
{
beta3=beta33
rhojy3=rhof(beta3)
IdigV=IdigVf(rhojy3)
bb=optim(betaI,rankw)
beta33=bb$par
    print(beta33) 
    bit=rbind(bit,beta33)
    obj=c(obj,bb$value)   
if(max(abs(beta3-beta33))<=10^(-3)){index=1;break}
       else{iter<-iter+1}

       }
     
     
     if(iter==11){resb[i,]=unique(bit[obj==min(obj),])}
      else{ resb[i,]=beta33}
	print(cbind(resb[i,],resjy[i,]) )
print(c(i,iter))
}

SEb=sqrt(diag(cov(resb)))
 SEjy=sqrt(diag(cov(resjy)))

save.image(file="pupweight.RData")
Z2=Sys.time()
(Z2-Z1)




