require(MASS)
require(mvtnorm)
require(abind)
require(magic)
require(Rlab)
require(animation)
source("rankfunction.R")
Z1=Sys.time()




labor=read.table(file="laborpain.txt",header=T,sep=" ")


N=length(labor$Patient)
lab0<-c(labor[,2],labor[,3],labor[,4],labor[,5],labor[,6],labor[,7])
lab0<-cbind(lab0,rep(labor$Patient,6))
lab0<-cbind(lab0,rep(labor$trt,6))

lab0<-cbind(lab0,rep(1:6,rep(length(labor$trt),6)))
lab0<-as.data.frame(lab0)

names(lab0)[1:4]<-c("y","ID","trt","Time")
lab0$ID<-lab0$ID + 100*lab0$trt

lab0<-lab0[order(lab0$ID),]
lab0<-lab0[!is.na(lab0$y),]
lab0$trt=1-lab0$trt
lab0$TT<-lab0$trt*lab0$Time
#lab0$Times=30*lab0$Time


ni= as.numeric(table(lab0$ID))
#as.vector(tapply(rep(1,length(lab0$ID)),lab0$ID,sum))
M=sum(ni)
M2=sum(ni^2)
M3=sum(ni^3)
M4=sum(ni^4)



n0=rep(0,M)
nn=rep(ni,times=ni)
n0i=outer(n0,nn,"+")
ni1=nn-1
ni10=outer(ni1,n0,"+")
mni=rep(M-ni,times=ni)
mni0=outer(mni,n0,"+")
nii1=rep(ni*(ni-1),times=ni)
nii10=outer(nii1,n0,"+")
nni=outer((M-nn),nn,"-")

d22=matrix(1,nrow=ni[1])
for (i in 1:(N-1)) {
d22=adiag(d22,matrix(1,nrow=ni[i+1]))
  }

############################
#
#############################
a1=(M-ni)
a2= M2-ni^2
a12=a1^2-a2
a21=a2-a1
############################
#for  correlation coefficients
############################
d11=(M3-3*M2+2*M)
dd2=(M4-6*M3+11*M2-6*M)
d33=(M2*(1+M)-M3-M^2)
d44=2*M^2-(3*M+2)*M2+(3+M)*M3-M4
d55=(1+M)*M2-M3-M^2
d66=M^2-(2*M+1-M2)*M2+2*M3-M4
d77=M^3+2*M3-3*M*M2
d88=2*M4-M^3-2*(M+1)*M3+ (M^2+3*M-M2)*M2

p1=p2=0.5
p11=p1^2
p12=p1*p2
p22=p2^2

  sigma11=p1*(1-p1)
  sigma22=p2*(1-p2)
  sigma1=sqrt(sigma11 )
  sigma2=sqrt(sigma22)
  sigma12=sigma1*sigma2

  rho1=rho7=1/3
  rho2=rho4=0


id=rep(c(1:N),times=ni)
dx=abs(outer(id,id,"-"))

x=as.matrix(lab0[,c(3:5)])
y=lab0$y
p=dim(x)[2]

betalm=lm(lab0$y~lab0$trt+lab0$Time+lab0$TT -1 )$coef
  beta0=c(-9.85,0.68,13.33)
betaI=optim(beta0,rankjy)$par

  XX=array(0,dim=c(M,M,p))
  Dij=NULL
 for(i in 1:p){

 XX[,,i]=outer(x[,i],x[,i],"-")
dij=colSums(XX[,,i])/M
 Dij=rbind(Dij,dij)
 }
nlm(ujy,p=betalm)

  optim(betalm,ujy)
    
beta22=beta33=betaI


index<-0
iter<-1
while(iter<=10)
{

##########################################################
#  estimate sigma_1, sigma_2 and (rho_k,k=0,...,8)
# eight types of correlation coefficients
##########################################################


beta2=beta22
rhoop=rhof(beta2)
digVop=digVf(rhoop)
covop=covf(rhoop)
Vop=t(covop)+digVop+covop
beta22=optim(beta2,rankop)$par

beta3=beta33
rhojy3=rhof(beta3)
IdigV=IdigVf(rhojy3)
beta33=optim(beta3,rankjy3)$par

   print(cbind(beta33,beta22))
if(max(abs(beta2-beta22),abs(beta3-beta33))<=10^(-4)){index=1;break}
       else{iter<-iter+1}

       }
       print(iter)
    betaO=beta22
betaB=beta33
 print(cbind(betaI,betaB,betaO))
   
 tt=outer(1/nn,1/(nn-1),"*")
 r=rank(y-x%*%betaB)-(M+1)/2
 A=outer(r,r,"*")*(dx==0)

 wiu=sum(A)-sum(diag(A))
 b=rep((ni-1),times=ni)
 wib=sum(b*r^2)
 rho=wiu/wib
rhof(betaB)


nsim<-3000		

resb<-resjy<-matrix(NA,nc=p,nr=nsim)
 beta33=betaI
for (i in 1:nsim)
{
	w<-rgamma(N,1,1)
	w<-rep(w,times=ni)
     	wij<-outer(w,w,"*")
    	resjy[i,]<-optim(betaI,Rankjyw)$par

index<-0
iter<-1
while(iter<=10)
{

beta3=beta33
rhojy3=rhof(beta3)
IdigV=IdigVf(rhojy3)
beta33=optim(betaI,rankw)$par
        
if(max(abs(beta3-beta33))<=10^(-4)){index=1;break}
       else{iter<-iter+1}

       }
     
       resb[i,]=beta33
	print(cbind(resb[i,],resjy[i,]) )
print(c(i,iter))
}

SEb=sqrt(diag(cov(resb)))
 SEjy=sqrt(diag(cov(resjy)))

save.image(file="labor-pain.RData")
Z2=Sys.time()
(Z2-Z1)


















rh=rhof(betaB)
v1=((a1+a21*rh[5]+ a12*rh[7])*sigma22+(ni-1)*(1+(ni-2)*rh[1])*sigma11+2*(ni-1)*a1*rh[3]*sigma12)/M^2
v2=((a1*rh[5]+ a21*rh[6]+ a12*rh[8])*sigma22+2* a1*((ni-2)*rh[4]-rh[3])*sigma12-sigma11+(ni-2)*((ni-3)*rh[2]-rh[1])*sigma11)/M^2
eps=as.vector(y-x%*%betaB)
ee=outer(eps,eps,"-")
ddx=(ee<0)
rankee=colSums(ddx-1/2)
S=rankee/M
A1=A2=matrix(0,ncol=p,nrow=p)
for(i in 1:N){
 a<-sum(ni[1:i])-ni[i]+1
 b<-sum(ni[1:i]) 
Ji=matrix(1,ncol=ni[i],nrow=ni[i])
IVi=1/(v1[i]-v2[i])*(diag(1,ni[i])-v2[i]/(v1[i]+(ni[i]-1)*v2[i])*Ji)
 
Di=Dij[,c(a:b)]
Si=S[c(a:b)]
#bDi=bDij[,c(a:b)]
B=Di%*%IVi
A1=A1+B%*%t(Di)
A2=A2+B%*%(Si%*%t(Si))%*%t(B)

}
B1=solve(A1)
VB=B1%*%A2%*%t(B1)
SEB=sqrt(diag(VB))


save.image(file="labor pain.RData")
Z2=Sys.time()
(Z2-Z1)







