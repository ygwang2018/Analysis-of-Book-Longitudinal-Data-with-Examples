##############################################
# JY's objective functions  Biometrika 2003
#############################################
rankjy=function(b)
{
eps=as.vector(y-x%*%b)
ep=as.vector(abs(outer(eps,eps,"-")))
d=sum(ep)/M^2
d
}
#######################################################################
#the betweent clusers   loss function
#######################################################################
rankb=function(b)
{
eps=as.vector(y-x%*%b)
ep=as.vector(abs(outer(eps,eps,"-"))*(dx>0))
d=sum(ep)/M^2
d
}
############################################
#the within clusers  loss function
#############################################
rankw=function(b)
{
eps=as.vector(y-x2*b)
ep=as.vector(abs(outer(eps,eps,"-"))*(dx==0))
d=sum(ep)/M
d
}
#############################################################
# the weighted functions proposed by Wang and Zhao (biometrics 2008)
#############################################################
weight=function(b)
{
eps=as.vector(y-x%*%b)
er=rank(eps)-(M+1)/2   
a=outer(er,er,"*")*(dx==0)
numer=sum(a)-sum(diag(a))
b=rep((ni-1),times=ni)
denom=sum(b*er^2)
rho_mom=numer/denom
w=rep(1/(1+(ni-1)*rho_mom),times=ni)
list(w=w, rho_mom=rho_mom)
 }
 
###########################################################
# the objective function proposed by Wang and Zhao (2008)
############################################################
rankwz=function(b)
{
 eps=as.vector(y-x%*%b)
 wobj=as.vector(outer(w,w,"*"))*as.vector(abs(outer(eps,eps,"-")))*as.vector(dx>0)
 obj=sum(wobj)/M^2
 obj
 }
###########################################################
# the weighted objective function for the independence model
############################################################
rankwJY=function(b)
{
 eps=as.vector(y-x%*%b)
 wobj=as.vector(outer(w,w,"*"))*as.vector(abs(outer(eps,eps,"-")))
 obj=sum(wobj)/M^2
 obj
}
###########################################################
# the weighted objective function for the independence model
############################################################
rankww=function(b)
{
 eps=as.vector(y-x2*b)
 wobj=as.vector(outer(w,w,"+")/2)*as.vector(abs(outer(eps,eps,"-")))*as.vector(dx==0)
 obj=sum(wobj)/M
 obj
} 
 ##################################
 #  Conditional beta2 obtained from the block diagnoal working matrix 
 ###################################
 rankBW=function(b)
{
 eps=as.vector(y-x2*b)
 wobj=as.vector(outer(w,w,"*")/2)*as.vector(abs(outer(eps,eps,"-")))*as.vector(dx>0)
 obj=sum(wobj)/M^2
 obj
 }
 
#######################################################
#    the optimal estimating function proposed by Wang and Fu
#######################################################

rankop=function(b)
{
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
ddx=(ee<0)
rankee=colSums(ddx-1/2)
S=rankee/M
d=Dij[,-1]%*%solve(Vop[-1,][,-1])%*%S[-1]
t(d)%*%d                                                                                         
}

#########################
#estimate the six correlation coefficients using the method of moment
###########################
rhof=function(b){   
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
eex=(ee<0)
wdx=eex*(dx==0)
bdx=eex*(dx>0)
  #p1=sum(wdx)/(M2-M)
  #p2=sum(bdx)/(M^2-M2)
  bas=rowSums(wdx)
  d1=sum(bas^2)
  d2=sum((bas%*%d22)^2)
  bbas=rowSums(bdx)
  bbs=(bdx%*%d22)
  d3=sum(bbs^2)
  d4=sum(bbas^2)
  d5= sum((bbas%*%d22)^2)
  see=rowSums(eex)
  d6=sum(see^2)
  d7= sum((see%*%d22)^2)
  d8=sum((t(d22)%*%bbs)^2)
# rho1=((2*d1-2*sum(ni10*wdx)+d11)/(2*d11) -p11)/sigma11
# rho2=((d2-sum(bas)-d11)/dd2-p11)/sigma11
 rho3=((d6-d1-d4+d33-sum(mni0*wdx)-sum(ni10*bdx))/(2*d33)-p12)/sigma12
#rho4=((d7-d2-d5+d44-sum(nii10*bdx)-sum((ni10-1)*mni0*wdx))/(2*d44)-p12)/sigma12
 D5= 2*d3-2*sum(bdx*n0i)+d55
 rho5=(D5/(2*d55)-p22)/ sigma22
 rho6=((d8-D5-sum(bdx) )/d66-p22)/sigma22
  rho7= (((2*(d4-d3)+d77-2* sum(nni*bdx)) )/(2*d77)- p22)/ sigma22
 rho8= ((2*(d5+d3-d4-d8)+d88-2*sum(ni10*nni*bdx) )/(2*d88)-p22)/ sigma22
 hatrho=c(rho1,rho2,rho3,rho4,rho5,rho6,rho7,rho8)
hatrho
      }
      
########################################
#the inverse matrix of the diagonal matrix
########################################
IdigVf=function(rh)
{      
v1=((a1+a21*rh[5]+ a12*rh[7])*sigma22+(ni-1)*(1+(ni-2)*rh[1])*sigma11+2*(ni-1)*a1*rh[3]*sigma12)/M^2
v2=((a1*rh[5]+ a21*rh[6]+ a12*rh[8])*sigma22+2* a1*((ni-2)*rh[4]-rh[3])*sigma12-sigma11+(ni-2)*((ni-3)*rh[2]-rh[1])*sigma11)/M^2
J1=matrix(1,ncol=ni[1],nrow=ni[1])

IdigV=1/(v1[1]-v2[1])*(diag(1,ni[1])- v2[1]/(v1[1]+(ni[1]-1)*v2[1])*J1 )
for(i in 2:N)
{
Ji=matrix(1,ncol=ni[i],nrow=ni[i])
if(max(v2[i]/v1[i])>0.95){v2[i]=0.90*v1[i]}
IVi=1/(v1[i]-v2[i])*(diag(1,ni[i])-v2[i]/(v1[i]+(ni[i]-1)*v2[i])*Ji)
IdigV=adiag(IdigV,IVi)
}
IdigV
    }
     
####################################
# the diagonal matrix
#################################     
digVf=function(rh)
{       
 v1=((a1+a21*rh[5]+ a12*rh[7])*sigma22+(ni-1)*(1+(ni-2)*rh[1])*sigma11+2*(ni-1)*a1*rh[3]*sigma12)/M^2
 v2=((a1*rh[5]+ a21*rh[6]+ a12*rh[8])*sigma22+2* a1*((ni-2)*rh[4]-rh[3])*sigma12-sigma11+(ni-2)*((ni-3)*rh[2]-rh[1])*sigma11)/M^2
J1=matrix(1,nrow=ni[1],ncol=ni[1])
digV=(v1[1]-v2[1])*diag(1,ni[1])+ v2[1]*J1
for(i in 2:N){
Ji=matrix(1,ncol=ni[i],nrow=ni[i])
Vi=(v1[i]-v2[i])*diag(1,ni[i])+ v2[i]*Ji
digV=adiag(digV,Vi)
}
digV
    }
    
#######################################
# the covariance 
#####################################    

covf=function(rh){
     VV=NULL
for(i in 1:(N-1))
 {
 Vij=matrix(0,nrow=ni[i],ncol=sum(ni[1:i]))
 for(j in (i+1):N)
{       
 eij= matrix(1,nrow=ni[i],ncol=ni[j])
 nij=ni[i]+ni[j]
 mnij= M-nij
 vij=1/(M)^2*((-mnij*rh[7]+((M2-ni[i]^2-ni[j]^2)-mnij*(nij-1))*rh[8]-1-(nij-2)*rh[5]-(ni[i]-1)*(ni[j]-1)*rh[6])*sigma22+((ni[i]-1)*(ni[i]-2)-(ni[j]-1)*(ni[j]-2))*rh[4]*sigma12)
 Vij=cbind(Vij,vij*eij)
}
VV=rbind(VV,Vij)
}
CV=rbind(VV,matrix(0,ni[N],M))
CV
}

###################################################
#the combined estimating functions proposed by Wang and Zhu 2006.
###################################################
rankwm=function(b){
 db =sum(xx1*xx2*(dx>0))
 Db=rbind(cbind(sum(xx1^2*(dx>0)),db),cbind(db,sum(xx2^2*(dx>0))))/M^2
 Dw=rbind(0,sum(xxi^2)/M)
eps=y-x%*%b
ee=outer(eps,eps,"-")
 Ub=NULL
 for(i in 1:p){
 Ub=rbind(Ub,sum(as.vector(XX[,,i])*as.vector(dx>0)*sign(as.vector(ee)))) 
}
epsw=y-x[,2]*b[2]
eew=outer(epsw,epsw,"-")
Uw=sum(as.vector(xxi)*sign(as.vector(eew)))/M
Ub=Ub/M^2
Uc=cbind(Db,Dw)%*%solve(Sigma)%*%rbind(Ub,Uw)
t(Uc)%*%Uc
}























#################################
#  the  resampling methods 
#################################
ubwrf=function(b){
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
ub=uw=NULL
for(i in 1:p)
{
ub=rbind(ub,sum(as.vector(XX[,,i])*as.vector(zij)*as.vector(dx>0)*sign(as.vector(ee)))) 
ub=rbind(ub,sum(as.vector(XX[,,i])*as.vector(zii)*as.vector(dx==0)*sign(as.vector(ee)))) 
}
ub=ub/M^2
uw=uw/M
list(ub,uw)
} 

 
vwf=function(b){
eps=as.vector(y-x[,2]*b[2])
 vw=0
 for(i in 1:N){
     xi=x2[id==i]
     ei=eps[id==i]
     eei= outer(ei,ei,"-")
     etai=sum(outer(xi,xi,"-")*(eei>0))
    vw=vw+etai^2
}
4*vw/M^2
}

vbwf=function(b)
{
  eps=as.vector(y-x%*%b)
  epsw=y-x[,2]*b[2]
  vbw=matrix(0,nr=p,nc=p-1)
for (i in 1:N)
  {
  xi=x[id==i,]
  ei=eps[id==i]
  eii= outer(epsw[id==i],epsw[id==i],"-")
  ex= outer(xi[,2],xi[,2],"-")
  psi=sum(ex*(eii>0))
  etai=rep(0,p)
for(j in 1:N)
  {
  if(j==i)next
  xj=x[id==j,]
  ej=eps[id==j]
  eij=outer(ei,ej,"-")
etai= etai+rbind(sum(outer(xi[,1],xj[,1],"-")*((eij>0)-1/2)),sum(outer(xi[,2],xj[,2],"-")*((eij>0)-1/2)))
}    
vbw=vbw+etai*psi
}
8*vbw/M^3
 }

vbf=function(b)
 {
 eps=as.vector(y-x%*%b)
 vb=matrix(0,nc=p,nr=p)
 for(i in 1:N){
     xi=x[id==i,]
     ei=eps[id==i]
     etai=rep(0,p)
 for(j in 1:N){
   if(j==i) next
      xj=x[id==j,]
      ej=eps[id==j]
 for(k in 1:ni[i]) {
      xik=xi[k,]
      eik=ei[k]
      for(l in 1:ni[j])  {
      xjl=xj[l,]
      ejl=ej[l]
   etai= etai+(xik-xjl)*((eik-ejl>0)-1/2)           
 } 
}
}
vb=vb+etai%*%t(etai)
 }
16*vb/M^4
 }







rankjy2=function(b)
{
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
ddx=(ee<0)
rankee=colSums(ddx-1/2)
S=rankee/(M)
d=Dij[,-1]%*%solve(digVjy2[-1,][,-1])%*%S[-1]
t(d)%*%d

}

################################
# using  the block diagnoal matrix  as a working matrix
###########################
rankjy3=function(b)
{
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
ddx=(ee<0)
rankee=colSums(ddx-1/2)
S=rankee/(M)
d=Dij%*%IdigV%*%S
t(d)%*%d

}
