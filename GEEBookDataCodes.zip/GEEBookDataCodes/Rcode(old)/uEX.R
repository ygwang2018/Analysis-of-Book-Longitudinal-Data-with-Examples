require(MASS)
require(mvtnorm)
require(abind)
require(magic)
require(Rlab)

source("rankfunction.R")
Z1=Sys.time()

m=5000
N=60
#################################
#unbalanced design
###################################
ni=round(runif(N,2,10))

M=sum(ni)
M2=sum(ni^2)
M3=sum(ni^3)
M4=sum(ni^4)
#############################
#ture value
############################
betat=c(1,1)
p=length(betat)
n0=rep(0,M)
nn=rep(ni,times=ni)
n0i=outer(n0,nn,"+")
ni1=nn-1
ni10=outer(ni1,n0,"+")
mni=rep(M-ni,times=ni)
mni0=outer(mni,n0,"+")
nii1=rep(ni*(ni-1),times=ni)
nii10=outer(nii1,n0,"+")
nni=outer((M-nn),nn,"-")
d22=matrix(1,nrow=ni[1])
for (i in 1:(N-1))
{
d22=adiag(d22,matrix(1,nrow=ni[i+1]))
}
############################
#
#############################
a1=(M-ni)
a2= M2-ni^2
a12=a1^2-a2
a21=a2-a1
############################
#for  correlation coefficients
############################
d11=(M3-3*M2+2*M)
dd2=(M4-6*M3+11*M2-6*M)
d33=(M2*(1+M)-M3-M^2)
d44=2*M^2-(3*M+2)*M2+(3+M)*M3-M4
d55=(1+M)*M2-M3-M^2
d66=M^2-(2*M+1-M2)*M2+2*M3-M4
d77=M^3+2*M3-3*M*M2
d88=2*M4-M^3-2*(M+1)*M3+ (M^2+3*M-M2)*M2

p1=p2=0.5
p11=p1^2
p12=p1*p2
p22=p2^2

sigma11=p1*(1-p1)
sigma22=p2*(1-p2)
sigma1=sqrt(sigma11 )
sigma2=sqrt(sigma22)
sigma12=sigma1*sigma2
rho1=rho7=1/3
rho2=rho4=0
rho=seq(from=0.0,to=0.9,by=0.15)
k=length(rho)
res=NULL
nom=6
allest1= allest2=array(0,dim=c(m,nom,k))
betaI=betab=betawb=betaw=betaWM=betaB=matrix(0,ncol=p,nrow=m)
Method=c(1:nom)
id=rep(c(1:N),times=ni)
dx=abs(outer(id,id,"-"))
x1=rep(rep(c(0,1),each=N/2),times=ni)
for(j in 1:k){
         rhot=rep(rho[j],nom)
for(l in 1:m){
      cat("simulation no.", c(j,l),"\n")
x2=rnorm(M)
x=cbind(x1,x2)
#####################################
#exchangeable  structure  multivariate normal distribution
#####################################
epislon=NULL
for(i in 1:N)
{
e=as.matrix(rep(1,ni[i]))
mu=rep(0,ni[i])
sigma=(1-rho[j])*diag(ni[i])+rho[j]*e%*%t(e)
epislon=c(epislon,rmvnorm(1,mean=mu,sigma))
}
####################################################
y=x%*%betat+epislon
dat=as.data.frame(cbind(y,x1,x2,id,rep(ni,times=ni)))
betalm=lm(y~x)$coef[-1]
##################################
#  the independence method
##############################
betaI[l,]=optim(betalm,rankjy)$par
beta0=betaI[l,]
##################################
#the between-cluster loss function
#################################
betab[l,]=optim(beta0,rankb)$par
##################################
# the within cluster loss function
####################################
betaw[l,]=c(beta0[1],optim(beta0[2],rankw)$par)
#######################################
# Wang and Zhao's method
##############################
w=weight(beta0)$w
betawb[l,]=optim(beta0,rankwz)$par

XX=array(0,dim=c(M,M,p))
Dij=NULL
 for(i in 1:p){
 XX[,,i]=outer(x[,i],x[,i],"-")
 Dij=rbind(Dij,colSums(XX[,,i])/M)
 }
 xx1=XX[,,1]
 xx2=XX[,,2]
 xxi=(xx2*(dx==0))

##################################
# the  combined method
###################################
vb=vbf(beta0)
vw=vwf(beta0)
vbw=vbwf(beta0)
Sigma=rbind(cbind(vb,vbw),cbind(t(vbw),vw))
betaWM[l,]=optim(beta0,rankwm)$par
############################
#block diagonal matrix
############################
beta33=beta0
index<-0
iter<-1
while(iter<=10)
{
beta3=beta33
rhojy3=rhof(beta3)
IdigV=IdigVf(rhojy3)
beta33=optim(beta3,rankjy3)$par
if(max(abs(beta3-beta33))<=10^(-4)){index=1;break}
       else{iter<-iter+1}
}
print(iter)
betaB[l,]=beta33
}
allest1[,,j]=cbind(betaI[,1],betab[,1],betaw[,1],betaWM[,1],betawb[,1],betaB[,1])
allest2[,,j]=cbind(betaI[,2],betab[,2],betaw[,2],betaWM[,2],betawb[,2],betaB[,2])
rhot=rep(rho[j],nom)
bias1=allest1[,,j]-betat[1]
bias2=allest2[,,j]-betat[2]
mbias1= apply(bias1,2,mean)*100
mse1=apply(bias1^2,2,mean)*100
est1=apply(allest1[,,j],2,mean)
mbias2= apply(bias2,2,mean)*100
mse2=apply(bias2^2,2,mean)*100
est2=apply(allest2[,,j],2,mean)
mse1=mse1[1]/mse1
mse2=mse2[1]/mse2
est=cbind(Method,rhot,est1,mbias1,mse1,est2,mbias2,mse2)
res=rbind(res,est)
}
res=as.data.frame(res)
res$Method=as.factor(res$Method)
res$Method=c("IN","BT","WT","CM","WZ","BK")
res$no.sub=N
res$no.sim=m
print(cbind(res[,-c(3:8)],round(res[,c(3:8)],3)))
save.image(file="newunbalancedEX.RData")
para=rep("beta1",length(res[,1]))
a=cbind(res[,c(1,2,5)],rep("beta1",length(res[,1])))
b=cbind(res[,c(1,2,8)],rep("beta2",length(res[,1])))
colnames(a)=c("Method","rho","MSE","beta")
colnames(b)=c("Method","rho","MSE","beta")

mse=as.data.frame(rbind(a,b))
mse$Method=as.factor(mse$Method)
mse$beta=as.factor(mse$beta)
library(lattice)

xyplot(MSE~ rho|beta, data=mse,group=Method,type="b",strip = strip.custom(strip.names =FALSE, strip.levels =TRUE),
par.settings=simpleTheme(pch=c(1:nom),col=rep(1,nom)),xlab=expression(rho),ylab="Relative Efficiency",auto.key = list(points=TRUE,lines=TRUE,columns = 2,space="top"))

xyplot(MSE~ rho, data=a,group=Method,type="b",strip = strip.custom(strip.names =FALSE, strip.levels =TRUE),
par.settings=simpleTheme(pch=c(1:nom),col=c(1:nom)),xlab=expression(rho),ylab="Relative Efficiency",auto.key = list(points=TRUE,lines=TRUE,columns = 2,space="top"))
savePlot(file="newuEX_b1.pdf", type="pdf")
xyplot(MSE~ rho, data=b,group=Method,type="b",strip = strip.custom(strip.names =FALSE, strip.levels =TRUE),
par.settings=simpleTheme(pch=c(1:nom),col=c(1:nom)),xlab=expression(rho),ylab="Relative Efficiency",auto.key = list(points=TRUE,lines=TRUE,columns = 2,space="top"))
savePlot(file="newuEX_b2.pdf", type="pdf")

Z2=Sys.time()
(Z2-Z1)










