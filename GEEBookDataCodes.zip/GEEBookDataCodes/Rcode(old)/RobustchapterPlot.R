library(lattice)
setwd("E:\\Pub\\latex forpubs\\Fu&Wang&Zhu2015GaussESt-CSDA")
dat=as.data.frame(read.table("dental.txt",header=TRUE,sep=""))
######################### # MAIN program #########################
head(dat)
xyplot(distance~age|gender,group=id, type="b",ylab="Distance (mm)",xlab="Age (year)", data=dat)
dat$gencode[dat$gender=="Girl"]=-1
dat$gencode[dat$gender=="Boy"]=1

bwplot(distance~age|gender,group=id,horizontal = FALSE,outer = TRUE, type="b",ylab="Distance (mm)",xlab="Age (year)", data=dat)



library(RColorBrewer)
library(latticeExtra)
library(reshape)
setwd("E:\\Pub\\latex forpubs\\Fu&Wang2012Biometrics\\Realdata")
pain=as.data.frame(read.table("pain.txt",header=TRUE,sep="\t"))

pain=pain[!is.na(pain$paintol),]

pain$trial=as.factor(pain$trial)
N=length(unique(pain$id))

###################################################
# plot graphics
###################################################
lab="Pain tolerance (sec)"
levels(pain$cs)=c("attender  group ",  "distractor  group")
levels(pain$treatment)=c("attention", "distraction",  "no interventions")


loglab=expression(paste("Pain tolerance in"," ", log[2]," ", "seconds",seq=" "))
xyplot(paintol ~ trial | cs*sex, group = id, data = pain,type ="b",col=1,ylab=lab)

#pain$cs=factor(pain$cs)

#levels(pain$cs)=paste(levels(pain$cs), "baseline group",seq="")
d=xyplot(lpaintol ~ trial | treatment*cs,as.table=TRUE, group = id, data = pain,type ="b",xlab="Trial",ylab=loglab)


plot(useOuterStrips(d))


pp=cast(id~trial, value="lpaintol",data=pain)
names(pp)[2:5]=paste("Trial",names(pp)[2:5])


splom(~pp[2:5],data=pp,type=c("p","r"),as.matrix=TRUE,xlab=loglab,ylab=loglab,col=1)


pain$trial=as.numeric(pain$trial)
mpain=subset(pain, sex=="male")
fpain=subset(pain,sex=="female")
pp3=cast(sex+trial~., function(x) (median=median(x)),value="paintol",data=pain)
names(pp3)[3]="median"
head(pp3)
ff=pp3$sex=="female"
mm=pp3$sex=="male"

boxplot(log2(paintol)~trial,data=mpain,col=3,boxwex=0.25,ylim=c(2,9),at=1:4-0.2,xlab="Trial",pch=20,ylab=expression(paste("Pain tolerance in"," ", log[2]," ", "seconds", sep="")))
boxplot(log2(paintol)~trial,data=fpain,col=4,boxwex=0.25,at=1:4+0.2,add=TRUE,pch=20)
legend(0.15,9.25, c("boy","girl"),lty=c(1,3),col=c(3,4))
lines((pp3[2][mm,]-0.2),log2(pp3[3][mm,]),type="l",lty=1,col=3)
lines(pp3[2][ff,]+0.2,log2(pp3[3][ff,]),lty=3,col=4)