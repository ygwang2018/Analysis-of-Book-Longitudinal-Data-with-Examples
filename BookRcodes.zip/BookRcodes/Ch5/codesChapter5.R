rm(list=ls())
###################chapter 5 model selection#######################

##########################set up your own directory  (change to your own directory)########################
##########################################
#set working directory 
############################################
setwd("D:\\OneDrive\\GEEBook2020 (1)\\GEEBook2020\\GEEBookDataCodes2020")

############################source your function##########################
source("CriteriaFunctionChapter5.R")

#################################main codes################################


library(geepack)
library(emplik)
library(MESS)
library(glmnet)
library(quadprog)
library(kinship2)
library(magic)
library(xtable)
######################################################################
#Model selection 5.4.1 Example 1: hormone data 
#####################################################################


horm<-as.data.frame(read.table(file="control.dat",header=FALSE, sep=""))
colnames(horm)=c("id", "cycle","age","bmi","day", "logpdg" )
m=length(unique(horm$id))
ni=as.numeric(table(horm$id))
horm$id=rep(1:m,ni)
head(horm)
y=horm$logpdg


horm$TIME=(horm$day-mean(horm$day))/10
horm$AGE=(horm$age-mean(horm$age))/100
horm$BMI=(horm$bmi-mean(horm$bmi))/100

############################correlation structure is independence
model1.in=geeglm(logpdg~AGE+BMI+TIME,data=horm, id=id,family=gaussian, corstr="independence")
model2.in=update(model1.in,.~.+I(TIME^2))
model3.in=update(model2.in,.~.+I(TIME^3))
model4.in=update(model3.in,.~.+I(TIME^4))
model5.in=update(model4.in,.~.+I(TIME^5))
#############################################################calculate criteria   QIC and EQIC
model1=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model1.in, model.independence=model1.in)
model2=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model2.in, model.independence=model2.in)
model3=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model3.in, model.independence=model3.in)
model4=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model4.in, model.independence=model4.in)
model5=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model5.in, model.independence=model5.in)
resin=rbind(model1,model2,model3,model4,model5)


######################################Gaussian criteria
p=3
pp=c(p,p+1,p+2,p+3,p+4)
gausin=sapply(list(model1.in,model2.in,model3.in,model4.in,model5.in),function(x) Gau.geeglm("continuous",x))
GAIC.in=gausin+2*pp
GBIC.in=gausin+log(m)*pp

hormon.gausind=cbind(GAIC.in,GBIC.in)
hormon.ind=cbind(resin,hormon.gausind)


############################correlation structure is exchangeable
model1.ex=update(model1.in, corstr="exchangeable")
model2.ex=update(model1.ex,.~.+I(TIME^2))
model3.ex=update(model2.ex,.~.+I(TIME^3))
model4.ex=update(model3.ex,.~.+I(TIME^4))
model5.ex=update(model4.ex,.~.+I(TIME^5))
#############################################################calculate criteria
model1ex=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model1.ex, model.independence=model1.in)
model2ex=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model2.ex, model.independence=model2.in)
model3ex=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model3.ex, model.independence=model3.in)
model4ex=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model4.ex, model.independence=model4.in)
model5ex=QIC.CIC.geeglm(datatype="continuous",model.geeglm=model5.ex, model.independence=model5.in)

resex=rbind(model1ex,model2ex,model3ex,model4ex,model5ex)


################################Gaussian criteria

gausex=sapply(list(model1.ex,model2.ex,model3.ex,model4.ex,model5.ex),function(x) Gau.geeglm("continuous",x))
GAIC.ex=gausex+2*pp
GBIC.ex=gausex+log(m)*pp

hormon.gauex=cbind(GAIC.ex,GBIC.ex)
hormon.exc=cbind(resex,hormon.gauex)
#############################################################



# the top panel of Table 5.1 
print(hormon.ind[,c(1,7,10,11)], digits=6)
#the bottom of Table 5.1
print(hormon.exc[,c(1,8,11,12)],digist=5)


##############################################################



#5.4.2 Example 2: Madras Longitudinal Schizophrenia Study
#####################################################################################

madras<- read.table( file="madras.data.txt",sep="", header=TRUE)


colnames(madras) <- c(
  "ID",              # patient ID
  "Y",               # symptom indicator: binary
  "MONTH",           # month since hospitalization
  "AGE",             # age-at-onset (1= age<20 ; 0= age>=20)
  "GENDER",          # gender (1=female; 0=male)
  "MONTH.AGE",       # interaction term MONTH x AGE
  "MONTH.GENDER"     # interaction term MONTH x GENDER
)


ni=as.numeric(table(madras$ID))
m=length(unique(madras$ID)) #sample size
madras$id=rep(1:m,ni)
###############################geepack

madras.geeglmind=geeglm(Y~MONTH+AGE+GENDER+MONTH.AGE+MONTH.GENDER+AGE*GENDER,data=madras,id=id,family=binomial,corstr="independence")
madras.geeglmexc=update(madras.geeglmind,corstr="exchangeable")
madras.geeglmar1=update(madras.geeglmind,corstr="ar1")
###################################table 5.2

summary(madras.geeglmind)$coefficients
xtable(summary(madras.geeglmind)$coefficients,digits=4)
summary(madras.geeglmexc)
summary(madras.geeglmexc)$coefficients

xtable(summary(madras.geeglmexc)$coefficients,digits=4)

summary(madras.geeglmar1)$coefficients

xtable(summary(madras.geeglmar1)$coefficients,digits=4)
###################################table 5.3######################################
###################################QIC and CIC
madrasQICCIC=sapply(list(madras.geeglmind, madras.geeglmexc, madras.geeglmar1), function(x) QIC.CIC.geeglm(datatype="binary",x,madras.geeglmind))
colnames(madrasQICCIC)=c("IN","EX","AR")



##################################################GAIC and GBIC
C=Gau.geeglm(datatype="binary",model.geeglm=madras.geeglmind)

madras.gauexc=Gau.geeglm(datatype="binary",model.geeglm=madras.geeglmexc)
madras.gauar1=Gau.geeglm(datatype="binary",model.geeglm=madras.geeglmar1)

madras.gau=c(madras.gauind,madras.gauexc,madras.gauar1)
p=7
np=c(p,p+1,p+1)
madrasGAIC=madras.gau+2*np
madrasGBIC=madras.gau+log(m)*np

madras.gau=rbind(madrasGAIC,madrasGBIC)

#####################################EAIC EBIC
ELind=elr.stall(datatype="binary",madras.geeglmind)
ELexc=elr.stall(datatype="binary",madras.geeglmexc)
ELar1=elr.stall(datatype="binary",madras.geeglmar1)

EL=c(ELind,ELexc,ELar1)
madras.EAIC=EL+2*np
madras.EBIC=EL+np*log(m)


madres=rbind(madrasQICCIC,madras.gau,madras.EAIC,madras.EBIC)
##table 5.2
print(madres[c(1,3,5,6,11:14),],digits=5)

#library(MESS)
qic.res=rbind(QIC(madras.geeglmind),QIC(madras.geeglmexc),QIC(madras.geeglmar1))
rownames(qic.res)=c("IN","EX","AR")
print(qic.res)
xtable(qic.res)
############################################################
#5.4.2 Example 3. Progabide study
##################################################################################
library(Rlab)
data(seizure)
## Diggle, Liang, and Zeger (1994) pp166-168, compare Table 8.10
seizure<- reshape(seizure,
                  varying=list(c("base","y1", "y2", "y3", "y4")),
                  v.names="y", times=0:4, direction="long")

seizure <- seizure[order(seizure$id, seizure$time),]
seizure$t <- ifelse(seizure$time == 0, 8, 2)
seizure$base<- ifelse(seizure$time == 0, 0, 1)
head(seizure)


loc=with(seizure,id[which.max(y)])
###########################################################################
#remove the outliers, and rerun the following codes, 
#the results on the right panel of Table 5.6 and Table 5.7 and 5.8 can be obtained.
################################################################################

#seizure=seizure[seizure$id!=loc,]  #remove the outliers

m=length(unique(seizure$id))


M=length(seizure[,1])

ni=as.numeric(table(seizure$id))

YY=with(seizure,matrix(y,nc=5,byrow=T))
# the left panel of Table 5.4
cor(YY)

x=with(seizure,cbind(rep(1,M),base,trt,log(age),base*trt))
#############################

seiz.geeglmind=geeglm(y ~offset(log(t)) +base+trt+log(age)+base:trt, id = id,data=seizure, corstr="independence", family=poisson)

seiz.geeglmexc=update(seiz.geeglmind,corstr="exchangeable")
seiz.geeglmar1=update(seiz.geeglmind, corstr="ar1")
summary(seiz.geeglmind)
summary(seiz.geeglmind)$coefficients
xtable(summary(seiz.geeglmind)$coefficients,digits=4)
xtable(summary(seiz.geeglmexc)$coefficients,digits=4)
xtable(summary(seiz.geeglmar1)$coefficients,digits=4)
#####################################################
######################################QIC and CIC
seizQIC=sapply(list(seiz.geeglmind, seiz.geeglmexc, seiz.geeglmar1), function(x) QIC.CIC.geeglm(datatype="count",x,seiz.geeglmind))
colnames(seizQIC)=c("IN","EX","AR")


##################################################GAIC and GBIC
seiz.gauind=Gau.geeglm(datatype="count",model.geeglm=seiz.geeglmind)

seiz.gauexc=Gau.geeglm(datatype="count",model.geeglm=seiz.geeglmexc)
seiz.gauar1=Gau.geeglm(datatype="count",model.geeglm=seiz.geeglmar1)

seiz.gau=c(seiz.gauind,seiz.gauexc,seiz.gauar1)
p=dim(x)[2]
np=c(p,p+1,p+1)
seizGAIC=seiz.gau+2*np
seizGBIC=seiz.gau+log(m)*np
#####################################EAIC EBIC

seiz.ELind=elr.stall("count",seiz.geeglmind)
seiz.ELexc=elr.stall("count",seiz.geeglmexc)
seiz.ELar1=elr.stall("count",seiz.geeglmar1)

seiz.ELC=c(seiz.ELind,seiz.ELexc,seiz.ELar1)


seiz.EAIC=seiz.ELC+2*np
seiz.EBIC=seiz.ELC+np*log(m)
##################################################CR
seiz.CRind=shof("count",seiz.geeglmind)
seiz.CRexc=shof("count",seiz.geeglmexc)
seiz.CRar1=shof("count",seiz.geeglmar1)
CR=c(seiz.CRind,seiz.CRexc,seiz.CRar1)
seiz.res=rbind(seizQIC,CR,seizGAIC,seizGBIC,seiz.EAIC,seiz.EBIC)
########################################################the left panel of table 5.8
print(seiz.res[c(1,3,5,6,11:15),],digits=5)

