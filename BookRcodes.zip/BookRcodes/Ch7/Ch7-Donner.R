
### this Rscript solve a given estimating equation
#library(pracma)
#library(spuRs)
#library(tidyverse)
#library(NLRoot)
# import data
Y1 <- c(118, 130)
Y2 <- c(111, 140, 125, 100)
Y3 <- c(107 ,110 ,125)
Y4 <- c(115, 115)
Y5 <- c(127 ,122, 140)
Y6 <- c(126 ,123, 109, 134, 88)
Y7 <- c(90, 99)
Y8 <- c(140, 120)
Y9 <- c(110, 105, 138, 103)
Y10 <- c(109)
n <- c(2, 4, 3, 2, 3, 5, 2, 2, 4, 1)
Y <- list(Y1, Y2, Y3, Y4, Y5, Y6, Y7, Y8, Y9, Y10)
Ybar <- sapply(Y, mean)
N <- sum(n)
t <- function(rho) {1+(n-1)*rho}
SD <- function(rhohat){
  2*(1-rhohat)^2/sum(n*(n-1)*(1-(n-1)*rhohat)^2)
}
##### Donner
u <- function(rho){
  sum(n*Ybar/t(rho))/sum(n/t(rho))
}
term2 <- function(rho){
  A <- 0
  for (i in 1:10) {
    for (j in 1:(n[i]-1)) {
      for (k in (j+1):n[i]) {
        A <- A + 1
        1
      }
    }
  }
  return(2*rho*A)
}
sigma2 <- function(rho){
  (sum((t(rho)-rho)/t(rho)*sapply(lapply(Y, function(x)(x-u(rho))^2), mean))-term2(rho))/(N*(1-rho))
}
func1 <- function(rho){
  N*(1+log(sigma2(rho))+log(2*pi))+(N-10)*log(1-rho)+sum(log(t(rho)))
}
# find the minimizer result is 0.02662085.
nlm(func1, 0.5) # 0.5 is the start value

SD(0.026875)
