J1<-c(4,1,3,6,6,7,8,9)
J2<-c(2,3,8,4,5,5,7,7)
Data<-data.frame(J1,J2)
Means.Data<-sapply(Data, mean, na.rm=TRUE)#respective means 
Means.Data
ni<-8 ## n1=n2=8 
k<-2 # no. of families 
N<-ni*k
ybar<-1/N*sum(Data)
ybar
SSB<-sum(ni*(Means.Data-ybar)^2)
MSB<-SSB/(k-1)
MSB
SSW<-sum((Data[,1]-Means.Data[1])^2)+sum((Data[,2]-Means.Data[2])^2)
MSW<-SSW/(N-k)
MSW
n0<-8
rhohat<-(MSB-MSW)/(MSB+(n0-1)*MSW)
rhohat
