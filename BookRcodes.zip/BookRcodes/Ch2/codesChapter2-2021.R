
rm(list=ls())
##########################################
#set working directory 
##############################set up your own directory where the data are put##############
setwd("D:\\OneDrive\\GEEBook2020 (1)\\GEEBook2020\\GEEBookDataCodes2020")
###############################
library(lattice)
require(nlme)
#########################################
#2.1.1 HIV study Figure 2.1
##########################################
dat=read.table("hiv315.txt",header=TRUE)
head(dat)
dat=data.frame(dat)
n=length(unique(dat$id))
plot(dat$lgcopy~dat$day,type="n",xlab="Days",ylab=expression(log10("RNA")))
for(i in 1:n){
  lines(dat$day[dat$id==i],dat$lgcopy[dat$id==i],col=1)
}


####################################
#2.1.2 Progabide study 
####################################
seiz<-as.data.frame(read.table(file="seizure.data.txt",header=FALSE, sep=""))

names(seiz)=c("id", "counts","visit","trt","age","weeks")
seiz$medicine=as.factor(rep(c('Placebo','Progabide'), as.numeric(table(seiz$trt))))
head(seiz)

#########################################
#figure 2.2 boxplot
#######################################
library(lattice)
seiz$visit=factor(seiz$visit)
bwplot(counts~visit|medicine,  layout=c(2,1), xlab="Visit",
       ylab="The number of seizures",strip = strip.custom(strip.names = TRUE, strip.levels = TRUE),horizontal=FALSE,data=seiz, outline=TRUE, col=1)

###white and black figure 
library(ggplot2)
seiz$visit=factor(seiz$visit)
p<-ggplot(data=seiz,aes(x=visit,y=counts))+stat_boxplot(geom = "errorbar",width=0.5)
p1<-p+geom_boxplot()+labs(x="Visit",y="The number of seizures")+facet_wrap(~medicine)
p1+theme_bw()+theme(panel.grid.major=element_blank(),
                    panel.grid.minor=element_blank())
###############################################
#Figure 2.3 blue for placebo; red for progabide
##############################################
library(geepack)
data(seizure)
colnames(seizure)[c(6,1:4)]=c("baseline","visit 1","visit 2","visit 3","visit 4")
seizure$trt=as.factor(seizure$trt)
pairs(seizure[c(6,1:4)],pch=21,bg = c("blue","red")[unclass(seizure$trt)],main="Progabide study--two treatments")
#white and black figure #white ring is for progabide,black spot is for palcebo
pairs(seizure[c(6,1:4)],pch=c(21,1)[unclass(seizure$trt)],bg = c("black","white")[unclass(seizure$trt)],main="Progabide study--two treatments")

#############################################
#2.1.3 hormone data  Figure 2.4
#############################################

horme=as.data.frame(read.table(file="control.dat",header=FALSE))
colnames(horme)=c("id", "cycle","age","bmi","day", "logpdg" )

head(horme)
attach(horme)
fm=loess(logpdg~day,horme)

plot(logpdg~day,ylab="Log progesterone",xlab="Days in standardized menstrual cycle", xaxt = "n")
axis(side=1, at =seq(0,28,by=2), labels = TRUE, tick = TRUE,lty = "solid", col = NULL, col.ticks = NULL)
lines((spline(day,fitted(fm))),col="blue")
#################black and white figure
plot(logpdg~day,ylab="Log progesterone",xlab="Days in standardized menstrual cycle", xaxt = "n")
axis(side=1, at =seq(0,28,by=2), labels = TRUE, tick = TRUE,lty = "solid", col = NULL, col.ticks = NULL)
lines((spline(day,fitted(fm))),col="black",lwd=2)
detach(horme)
########################################################
#2.1.6 Labor pain study
########################################################

laborp=read.table(file="laborpain.txt",header=T,sep=" ")
head(laborp,10)
labor=reshape(laborp,varying=list(names(laborp)[-c(1,8)]), direction='long')

names(labor)=c("patient","trt","time","y","id")
labor$time=labor$time*30
labor=labor[!is.na(labor$y),]

labor=labor[order(labor$id),]
head(labor)
labor$group=rep(c("Active","Placebo"),times=c(189,169))
###############################
#Figure 2.5 parallel line plot
################################
xyplot(y~time|group, groups=id,data=labor,type="b",pch=20,xlab="Measurement time (minutes)",ylab="Pain score")

##black and white figure
library(RColorBrewer)
library(latticeExtra)
d=xyplot(y~time|group,col=1, groups=id,data=labor,type="b",pch=20,xlab="Measurement time (minutes)",ylab="Pain score")

theme=standard.theme("pdf")
theme$superpose.symbol$col=1
theme$superpose.line$col=1
theme$strip.border$col=1
theme$background$col="white"
theme$strip.background$col="white"

dnew=update(d,par.setting=theme)
plot(dnew)
####################################################
#Figure 2.6 boxplot
######################################################
bwplot(y~time|group,  data=labor,pars = list(boxwex = 0.15, staplewex = 0.25, outwex = 0.5),
       horizontal =F, groups=as.factor(trt),xlab="Measurement times",ylab="Pain score",col=1,layout=c(1,2))
###black and white figure
labor$time=as.factor(labor$time)
pp<-ggplot(data=labor,aes(x=time,y=y))+stat_boxplot(geom = "errorbar",width=0.5)
pp1<-pp+geom_boxplot()+labs(x="Measurement times",y="Pain score")+facet_wrap(~group)
pp1+theme_bw()+theme(panel.grid.major=element_blank(),
                     panel.grid.minor=element_blank())
####################################################
#Figure 2.7 histogram
######################################################
par(mfrow=c(1,2),mar=c(6,2.5,2.5,3))
labora=labor[labor$trt==1,]
hist(labora$y,freq=F,main="Histogram for active group ",xlab="Pain score ",col = "white")
lines(density(labora$y))
laborp=labor[labor$trt==0,]
hist(laborp$y,freq=F,main="Histogram for placebo group ",xlab="Pain score ",col = "white")
lines(density(laborp$y))
########################################################
#2.1.7 Labor Market Experience
########################################################
wage=as.data.frame(read.table(file="nlslme.csv",header = TRUE, sep=","))
wage=wage[!is.na(wage$age),]

length(unique(wage$idcode))

wage$south=as.factor(wage$south)
levels(wage$south)=c("Others","South")
####################################################
#Figure 2.8
####################################################
fig8=xyplot(lnwage~grade|south,xlab="Education (year)",layout=c(2,1),ylab="Log wage", data=wage, type="p", col=1 )
theme=standard.theme("pdf")
theme$superpose.symbol$col=1
theme$superpose.line$col=1
theme$strip.border$col=1
theme$background$col="white"
theme$strip.background$col="white"

fig8.new=update(fig8,par.setting=theme)
plot(fig8.new)

#######################################
#Figure 2.9
####################################################
boxplot(lnwage~grade, horizontal =F,xlab="Education (year)",ylab="Log wage", data=wage, type="p", col="white" )

###############################################
#2.1.8 water quality data
##################################################
allsite1<- read.delim("wiv_QW.txt",header=TRUE,sep="\t")
wih<-as.data.frame(allsite1)
datetxt <- as.Date(wih$Date,"%d/%m/%Y")
df <- data.frame(
  date = datetxt,
  year = as.numeric(format(datetxt, format = "%Y")),
  month = as.numeric(format(datetxt, format = "%m")),
  day = as.numeric(format(datetxt, format = "%d")))
wih$Year=df$year
wih$Month=df$month
wih$Date=as.Date(wih$Date,"%d/%m/%Y")

subset1=wih[wih$Name=="Total (CYANOPHYTES)",]
subset1$Site=factor(subset1$Site)
dat4=subset1[subset1$Site=="30004",]
dat16=subset1[subset1$Site=="30016",]
dat17=subset1[subset1$Site=="30017",]
dat18=subset1[subset1$Site=="30018",]
dat=rbind(dat4,dat16,dat17,dat18)
#############################################
#Figure 2.10
############################################
xyplot(Val~Date|Site, data=dat,type="b",xlab="Year",ylab="Values of total cyanophytes mg/L",col=1)
#############################################
#Figure 2.11
############################################
qqnorm(subset1$Val)
qqline(subset1$Val)