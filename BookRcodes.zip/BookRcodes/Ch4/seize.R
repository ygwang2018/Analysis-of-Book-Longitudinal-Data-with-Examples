
## 
seizue<-matrix(scan("datasets\\seizure.data.txt"),232,6,byrow=T)
r<-matrix(seize[,2],58,4,byrow=T)



##modified by YGWang  19 March 2008
seize<-as.data.frame(matrix(scan("seizure.data.txt"),236,6,byrow=T))
names(seize)=c("id", "y","Time","trt","base","age")
r<-matrix(seize[,2],59,4,byrow=T)



require(geepack)


## no patient 207 here?

seize$age<-log(seize$age)
seize$base<-log(seize$base/4)

fit<-geese(y~base+trt+base:trt+age,id=id,sca.link="log",
 corstr="ar1",family=poisson,data=seize)

summary(fit)


