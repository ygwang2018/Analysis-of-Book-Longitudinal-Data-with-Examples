cs<- function(r,n)
{
lags<-matrix(1,n,n)-diag(1,n,n)
r^lags
}
 
tb0<-matrix(0,5,1)
tb1<-matrix(0,5,1)
tb2<-matrix(0,5,1)
tb3<-matrix(0,5,1)
tb4<-matrix(0,5,1)
tphi<-matrix(0,5,1)
tp<-matrix(0,5,1)
tcorr<-matrix(0,5,1)


n<-59
m<-4
x<-with(seiz,cbind(rep(1,n*m),base,age,trt,base*trt))

r<-matrix(ep[,2],59,4,byrow=T)

x1<-matrix(x[,2],n,4,byrow=T)
x2<-matrix(x[,3],n,4,byrow=T)
x3<-matrix(x[,4],n,4,byrow=T)
x4<-matrix(x[5],n,4,byrow=T)

fit0<-glm(y~base+age+trt+base:trt,family=poisson,data=seiz)

y<-seiz$y


bb<-summary(fit0)$coef[1:5,1]

b0<-bb[1]
b1<-bb[2]
b2<-bb[3]
b3<-bb[4]
b4<-bb[5]

mu1<-fit0$fitted.values
res<-seiz$y-mu1

fit0$residuals
mu<-matrix(mu1,n,4,byrow=T)

## power variance 

fmin<-function(theta){
  phi1<-theta[1]
  p1<-theta[2]
	min<-sum((res^2-phi1*mu1^p1)^2/mu1^2) 
}

fit1<-optim(c(1,1.5),fmin)
phi<-fit1$par[1]
p<-fit1$par[2]

w<-mu1/mu1^p

fitp0<-geese(y~base+age+trt+base:trt,id=id,corstr="independence",family=poisson,
            sca.link="log",weights=w,data=seiz)
fitp1<-geese(y~base+age+trt+base:trt,id=id,corstr="ar1",family=poisson,sca.link="log",weights=w,data=seiz)
fitp2<-geese(y~base+age+trt+base:trt,id=id,corstr="exchangeable",sca.link="log",family=poisson, weights=w,data=seiz)
summary(fitp0)
summary(fitp1)
summary(fitp2)

round(t(summary(fitp0)$mean[2:5,1:2]),digits=3)
round(t(summary(fitp1)$mean[2:5,1:2]),digits=3)
round(t(summary(fitp2)$mean[2:5,1:2]),digits=3)



## Bartlett variance 

fmin<-function(theta){
  g1<-theta[1]
  g2<-theta[2]
  min<-sum((res^2-g1*mu1-g2*mu1^2)^2/mu1^2) 
}

fit1<-optim(c(1,0.5),fmin)
fit1

w<-mu1/(fit1$par[1]*mu1+fit1$par[2]*mu1^2)

fitb0<-geese(y~base+age+trt+base:trt,id=id,corstr="independence",family=poisson,
             sca.link="log",weights=w,data=seiz)
fitb1<-geese(y~base+age+trt+base:trt,id=id,corstr="ar1",family=poisson,sca.link="log",weights=w,data=seiz)
fitb2<-geese(y~base+age+trt+base:trt,id=id,corstr="exchangeable",sca.link="log",family=poisson, weights=w,data=seiz)
summary(fitb0)
summary(fitb1)
summary(fitb2)


round(t(summary(fitb0)$mean[2:5,1:2]),digits=3)
round(t(summary(fitb1)$mean[2:5,1:2]),digits=3)
round(t(summary(fitb2)$mean[2:5,1:2]),digits=3)




