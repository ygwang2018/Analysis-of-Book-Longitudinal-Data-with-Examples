#######################################
#chapter 4
################################################################################
#Table 4.2
####################################################
.libPaths(c("C:/Rlib"))
library(geepack)
library(yags)
data(seizure,package="geepack")
attach(seizure)
ybar.placebo=apply(seizure[,1:4][trt==0,],2,mean)
var.placebo=apply(seizure[,1:4][trt==0,],2,var)
ratio.pla=var.placebo/ybar.placebo
ybar.prog=apply(seizure[,1:4][trt==1,],2,mean)
var.prog=apply(seizure[,1:4][trt==1,],2,var)
ratio.prog=var.prog/ybar.prog
res=cbind(ybar.placebo,var.placebo,ratio.pla,ybar.prog,var.prog,ratio.prog)
print(res,digits=4)
detach(seizure)
