rm(list=ls())
###################chapter6 Robust Approaches#######################

##########################set up your own directory########################
setwd("D:\\OneDrive\\GEEBook2020 (1)\\GEEBook2020\\GEEBookDataCodes2020")
library(reshape)
library(lattice)
library(RColorBrewer)
library(latticeExtra)
library(ggplot2)
#############################################
#Chapter 6.3.4.1 Analysis of Dental data
#############################################
dat=as.data.frame(read.table(file="dental.txt",header=TRUE,sep=""))
######################### # MAIN program #########################
head(dat)
######################Figure 6.4
d=xyplot(distance~age|gender,horizontal=FALSE,data=dat,col=1,group = id,layout=c(2,1),type ="b",xlab="Age (year)",ylab="Distance (mm)",pch=21,lty=2,lwd=2)

theme=standard.theme("pdf")
theme$superpose.symbol$col=1
theme$superpose.line$col=1
theme$strip.border$col=1
theme$background$col="white"
theme$strip.background$col="white"

d2=update(d,par.setting=theme)
plot(d2)

####################Figure 6.5
library(lattice)
bwplot(distance~age|gender,data=dat, horizontal =FALSE,layout=c(2,1),col=4,xlab="Age (year)",ylab="Distance (mm)")
####################white and black figure
dat$gender=as.factor(dat$gender)
dat$age=as.factor(dat$age)

p<-ggplot(data=dat,aes(x=age,y=distance))+stat_boxplot(geom = "errorbar",width=0.5)
p1<-p+geom_boxplot()+labs(x="Age (year)",y="Distance (mm)")+facet_wrap(~gender)
p1+theme_bw()+theme(panel.grid.major=element_blank(),
                    panel.grid.minor=element_blank())


p1

####################Figure 6.6

hist(dat$distance,xlab="distance (mm)", main="Histogram of distance",freq=FALSE)

lines(density(dat$distance))

######################Table 6.2



##################################

library(quantreg)
library(copula)
library(MNM)
library(VGAM)
library(gee)
library(geepack)
library(psych)

source("RfunctionsChapter6.3.4.R")
dat=as.data.frame(read.table(file="dental.txt",header=TRUE,sep=""))
######################### # MAIN program #########################
head(dat)
dat$gencode[dat$gender=="Girl"]=-1
dat$gencode[dat$gender=="Boy"]=1
##################################################################################
#Results for tau=0.5 and tau=0.75 and tau=0.95
#can be obtained  via changing tau=0.5 and tau=0.75 and tau=0.95
####################################################################
tau=0.25

cc=sqrt(tau*(1-tau))
#####################################################################################
dat$age=dat$age-8
m=length(unique(dat$id))
nii=as.numeric(table(dat$id))
n=4
M=sum(nii)
x=cbind(rep(1,M),dat$gencode,dat$age,dat$gencode*dat$age)
y=dat$distance
p=dim(x)[2]
dx=abs(outer(dat$id,dat$id,"-"))
nn=rep(nii,nii)
######################################
#
#Independence  rq
#################################
rqest=rq(y~ x-1, tau=tau, data=dat)
summ=summary(rqest,se="boot")
sdi=summ$coefficients[,2]
pii=summ$coefficients[,4]
betaI=rqest$coef

#lkin.value=lk.crit(y,x,m,beta=betaI,alph=0,tau,str="in",pn=p)

################################
# independence estimating functions
#################################
betain0=betaI
index<-0
iter<-1
gamin=diag(p)/m

gamin=diag(p)/m
while(iter<=50)
{
  betain=betain0
  gamI=gamin
  
  err=y-x%*%betain
  
  ################################## 
  Sb=matrix(0,p,1) 
  Ds=matrix(0,p,p)  
  
  Vs=matrix(0,nr=p,nc=p)
  rr=sqrt(diag(x%*%gamI%*%t(x)))  
  dd=err/rr
  dS=dnorm(dd)/rr
  sS=1-tau-pnorm(dd)
  for(i in 1:m){  
    ni=nii[i]     
    idi=c(dat$id==i)      
    Xi=x[idi,]
    Ai.inv=(diag(1/cc,ni))
    
    Si= sS[idi]
    B=t(Xi)%*%Ai.inv
    Sb=Sb+B%*%Si
    Ds=Ds+B%*%Ai.inv%*%diag(dS[dat$id==i])%*%Xi  
    
    Vs=Vs+B%*%Ai.inv%*%Si%*%t(Si)%*%Ai.inv%*%t(B)
  }
  
  D.inv=solve(Ds)
  
  betain0=betain-D.inv%*%Sb
  
  gamin=D.inv%*%Vs%*%t(D.inv)
  if(max(abs(betain0-betain),abs(gamin-gamI))<=10^(-4)){index=1;break}
  else{iter<-iter+1}
  
}
print(iter) 
betaIs=betain0
VINs=diag(gamin)
lkins.value=lk.crit(y,x,m,beta=betaIs,alph=0,tau,str="in")

pis= 1-pnorm(abs(betaIs/sd(VINs)))
######################################
#
#exchangeable 
#################################  

betaex0=betaI
index<-0
iter<-1
gamex=diag(sdi^2)
rho.ex=0

while(iter<=50)
{
  betaex=betaex0
  gamI=gamex
  
  err=y-x%*%betaex
  tryex=optimize(lk.ex,c(0,1),maximum =TRUE)
  rho.ex=tryex$maximum
  
  print(c("exchangeable",rho.ex))
  ##################################
  
  Sb=matrix(0,p,1) 
  DI= Ds=matrix(0,p,p)
  Vs=matrix(0,nr=p,nc=p)
  rr=sqrt(diag(x%*%gamI%*%t(x)))
  
  dd=err/rr
  dS=dnorm(dd)/rr
  sS=1-tau-pnorm(dd)
  for(i in 1:m){  
    ni=nii[i]     
    idi=c(dat$id==i)      
    Xi=x[idi,]
    
    Ai.inv=diag(rep(1/cc,ni))
    Vi.inv=Ai.inv%*%cs.inv(rho.ex,ni)%*%Ai.inv
    Si= sS[idi]
    B=t(Xi)%*%Vi.inv    
    Sb=Sb+B%*%Si
    Ds=Ds+B%*%diag(dS[dat$id==i])%*%Xi  
    Vs=Vs+B%*%Si%*%t(Si)%*%t(B)
    DI=DI+t(Xi)%*%Ai.inv%*%Ai.inv%*%diag(dS[dat$id==i])%*%Xi 
  }
  
  D.inv=solve(Ds)
  
  betaex0=betaex-D.inv%*%Sb    
  gamex=D.inv%*%Vs%*%t(D.inv)
  if(max(abs(betaex0-betaex),abs(gamex-gamI))<=10^(-4)){index=1;break}
  else{iter<-iter+1}
  
}
print(iter) 
betaEX=betaex0
VEX=diag(gamex)
alph.ex=rho.ex
lkex.value=lk.crit(y,x,m,beta=betaEX,alph=rho.ex,tau,str="ex")

pex=1-pnorm(abs(betaEX/sd(VEX)))
#################################################################
#AR(1)
####################################################################

betaar0=betaI
index<-0
iter<-1
gamar=diag(sdi^2)


while(iter<=50)
{
  betaar=betaar0
  gamI=gamar   
  err=y-x%*%betaar
  
  tryar= optimize(lk.ar,c(-1,1),maximum =TRUE)
  rho.ar=tryar$maximum
  
  print(c("ar",rho.ar))
  ##################################  
  Sb=matrix(0,p,1) 
  DI= Ds=matrix(0,p,p)  
  Vs=matrix(0,nr=p,nc=p)
  rr=sqrt(diag(x%*%gamI%*%t(x))) 
  
  dd=err/rr
  dS=dnorm(dd)/rr
  sS=1-tau-pnorm(dd)
  for(i in 1:m){  
    ni=nii[i]     
    idi=c(dat$id==i)
    Xi=x[idi,]   
    Si= sS[idi]
    
    Ai.inv=diag(rep(1/cc,ni))
    Vi.inv=Ai.inv%*%ar.inv(rho.ar,ni)%*%Ai.inv
    
    B=t(Xi)%*%Vi.inv        
    Sb=Sb+B%*%Si
    Ds=Ds+B%*%diag(dS[dat$id==i])%*%Xi  
    Vs=Vs+B%*%Si%*%t(Si)%*%t(B)
    DI=DI+t(Xi)%*%Ai.inv%*%Ai.inv%*%diag(dS[dat$id==i])%*%Xi 
  }  
  D.inv=solve(Ds)
  
  betaar0=betaar-D.inv%*%Sb
  
  gamar=D.inv%*%Vs%*%t(D.inv)
  if(max(abs(betaar0-betaar),abs(gamar-gamI))<=10^(-4)){index=1;break}
  else{iter<-iter+1}
  
}
print(iter) 
betaAR=betaar0
VAR=diag(gamar)
alph.ar=rho.ar
lkar.value=lk.crit(y,x,m,beta=betaAR,alph=rho.ar,tau,str="ar")



par=1-pnorm(abs(betaAR/sd(VAR)))

#####################################################################
# MA(1)
####################################################################
betama0=betaI
index<-0
iter<-1
gamma=diag(p)/m

while(iter<=50)
{
  betama=betama0
  gamI=gamma
  err=y-x%*%betama
  tryma=optimize(lk.ma,c(0,0.9),maximum =TRUE)
  rho.ma= tryma$maximum
  
  print(c("ma",rho.ma))
  ##################################  
  Sb=matrix(0,p,1) 
  DI=Ds=matrix(0,p,p)  
  Vs=matrix(0,nr=p,nc=p)
  rr=sqrt(diag(x%*%gamI%*%t(x))) 
  
  dd=err/rr
  dS=dnorm(dd)/rr
  sS=1-tau-pnorm(dd)
  for(i in 1:m){  
    ni=nii[i]
    
    Rmai=ma(rho=rho.ma,n=ni)
    idi=c(dat$id==i)
    
    Ai=diag(rep(cc,ni))
    Xi=x[idi,]
    Vi=Ai%*%Rmai%*%Ai   
    Si= sS[idi]
    B=t(Xi)%*%solve(Vi)
    Sb=Sb+B%*%Si
    Ds=Ds+B%*%diag(dS[dat$id==i])%*%Xi  
    Vs=Vs+B%*%Si%*%t(Si)%*%t(B)
    DI=DI+t(Xi)%*%Ai.inv%*%Ai.inv%*%diag(dS[dat$id==i])%*%Xi 
  }
  
  D.inv=solve(Ds)
  betama0=betama-D.inv%*%Sb
  gamma=D.inv%*%Vs%*%t(D.inv)
  if(max(abs(betama0-betama),abs(gamma-gamI))<=10^(-4)){index=1;break}
  else{iter<-iter+1}
  
}
print(iter) 
betaMA=betama0
VMA=diag(gamma)
alph.ma=rho.ma
lkma.value=lk.crit(y,x,m,beta=betaMA,alph=rho.ma,tau,str="ma")



pma=1-pnorm(abs(betaMA/sd(VMA)))


lku=c(lkins.value, lkex.value,lkar.value,lkma.value)
GAIC=lku+2*c(p,p+1,p+1,p+1)
GBIC=lku+log(m)*c(p,p+1,p+1,p+1)




est=cbind(betaIs,betaEX,betaAR,betaMA)
cona=c("betaIs","betaEX","betaAR","betaMA")
rona=expression(beta[0],beta[1],beta[2],beta[3])
colnames(est)=cona
rownames(est)=rona
Vest=cbind(VINs,VEX,VAR,VMA)
Sdest=sqrt(Vest)
colnames(Sdest)=c("SD.IN","SD.EX","SD.AR","SD.MA")
rownames(Sdest)=rona
alpha=cbind(alph.ex,alph.ar,alph.ma)
pvalue=round(cbind(pii,pis,pex,par,pma),digits=4)

res=list(est,Vest,Sdest,pvalue,alpha,tau,GAIC,GBIC)

