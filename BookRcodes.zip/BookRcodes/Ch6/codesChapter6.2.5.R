rm(list=ls())



###################chapter6 Robust Approaches#######################

##########################set up your own directory########################
setwd("C:\\Users\\fuly737\\Dropbox\\GEEBook2016\\GEEBookDataCodes")

#############################################
#chapter 6.2.5 Reproductive study
#############################################
library(reshape)
library(lattice)
library(RColorBrewer)
library(latticeExtra)
library(geepack)
pain=as.data.frame(read.table("pain.txt",header=TRUE,sep="\t"))
head(pain, n=10)
pain=pain[!is.na(pain$paintol),]

pain$trial=as.factor(pain$trial)

###################################################
# Figure 6.1
###################################################

levels(pain$cs)=c("attender group ",  "distractor group")
levels(pain$treatment)=c("attention", "distraction",  "no intervention")
levels(pain$sex)=c("girl", "boy")

loglab=expression(paste("Pain tolerance in",log[2]," ",  "seconds",seq=" "))


d=xyplot(lpaintol ~ trial | treatment*cs,as.table=TRUE, group = id, data = pain,type ="b",xlab="Trail",ylab=loglab)


plot(useOuterStrips(d,strip.left = TRUE))


#########################################
#Figure 6.2 boxpot
#######################################


pain$trial=as.numeric(pain$trial)
mpain=subset(pain, sex=="boy")
fpain=subset(pain,sex=="girl")
pp3=cast(sex+trial~., function(x) (median=median(x)),value="paintol",data=pain)
names(pp3)[3]="median"
head(pp3)
ff=pp3$sex=="girl"
mm=pp3$sex=="boy"

boxplot(log2(paintol)~trial,col=3,data=mpain,boxwex=0.35,ylim=c(2,9),at=1:4-0.2,xlab="Trail",ylab=loglab)
boxplot(log2(paintol)~trial,col=4,data=fpain,boxwex=0.35,at=1:4+0.2,add=TRUE)
legend(0.15,9.2, c("boy","girl"),lty=c(1,2),col=c(5,1))
lines((pp3[2][mm,]-0.2),log2(pp3[3][mm,]),col=5,type="l",lty=1)
lines(pp3[2][ff,]+0.2,log2(pp3[3][ff,]),lty=2)
########################################
# Figure 6.3 corr plot
#####################################
pp=cast(id~trial, value="lpaintol",data=pain)
names(pp)[2:5]=paste("Trail",names(pp)[2:5])
splom(~pp[2:5],data=pp,type=c("p","r"),as.matrix=TRUE,xlab=loglab,ylab=loglab,col=1)

#######################################
#Table 6.1
#######################################

source("RankfunctionsChapter6.2.5.R")
pain=as.data.frame(read.table("pain.txt",header=TRUE,sep="\t"))

pain=pain[!is.na(pain$paintol),]



pain$trt=as.character(pain$treatment)
pain$trt[pain$trial<4]="baseline"

#####################################################
#N is the number of subjects
#M is the total number of observations
#ni is the number of observations for each subject
###################################################
bb=boxplot(log2(paintol)~trial,data=pain,boxwex=0.25,at=1:4-0.2,xlab="Trial",ylab=expression(paste("Pain tolerance in"," ", log[2]," ", "seconds", sep="")))

index=seq(1,dim(pain)[1])
out=index[pain$trial%in%bb$names[bb$group] & log2(pain$paintol) %in% bb$out]
#pain=pain[-out,]#remove the outliers

#####################################################
#N is the number of subjects
#M is the total number of observations
#ni is the number of observations for each subject
###################################################

M=length(pain[,1])
ni=as.numeric(table(pain$id))
N=length(unique(pain$id))
pain$ID=rep(1:N,times=ni)

geeI=geeglm(y~x,data=pain,id=ID,family=gaussian,corstr="independence")
summary(geeI)

geeEX=geeglm(y~x,data=pain,id=ID,family=gaussian,corstr="exchangeable")
summary(geeEX)
betaEX=summary(geeEX)$coef[,1]
SE_EX=summary(geeEX)$coef[,2]
p_EX=summary(geeEX)$coef[,4]

geeAR=geeglm(y~x,data=pain,id=ID,family=gaussian,corstr="ar1")
summary(geeAR)
betaAR=summary(geeAR)$coef[,1]
SE_AR=summary(geeAR)$coef[,2]
p_AR=summary(geeAR)$coef[,4]
table(pain$sex)

pain$B=pain$A=pain$D=pain$Na=pain$G=rep(0,M)

pain$B[pain$cs=="attender"]=1
pain$A[pain$trt=="attend"]=1
pain$D[pain$trt=="distract"]=1
pain$Na[pain$trt=="no directions"]=1
pain$G[pain$sex=="female"]=1

y=pain$lpaintol
x=cbind(pain$B, pain$A*pain$B,pain$D*pain$B,pain$Na*pain$B, pain$A*(1-pain$B),pain$D*(1-pain$B),pain$Na*(1-pain$B),pain$G)
p=dim(x)[2]
id=pain$ID
dx=abs(outer(id,id,"-"))
#######################################################
# the estimates based on the independence workong model
#######################################################

mlm=lm(y~x)

summary(mlm)
betalm=mlm$coef[-1]

#############################################
#  estimates based on the independence working model 
############################################

betaI=optim(betalm,rankjy)$par

###############################################################
# the estimates based on the simple weighted estimating functions
##############################################################


w=weight(betaI)$w
print(weight(betaI)$rho_mom)

betaWZ=optim(betaI,rankwz)$par

cwr=cov_u(betaWZ,w)$covu
Gammb=diag(1,p)
T=Gammb+1
itn=0
while(max(abs((Gammb-T)/Gammb))>0.001){
  
  
  bb=betaWZ
  nb=betaWZ+0.01
  while(max(nb-bb)>0.001){
    d=Db(Gammb,bb)
    bb=nb
    nb=bb+solve(d)%*%U2(bb)$obj
    
  }
  itn=itn+1
  T=Gammb
  Gammb=(solve(d)%*%cwr%*%solve(d))
  
  print(itn)
}

itn
SE_WZ=sqrt(diag(Gammb))


##################################################################
# estimates by Wang and Zhu's (2006) method
################################################################
w=rep(1,M)
X2=matrix(NA,nr=M^2,nc=p)
if(p==1) X2=as.vector(outer(x,x,"-"))
if(p>1)
  for(i in 1:p)
  {
    
    X2[,i]=as.vector(outer(x[,i],x[,i],"-"))
  }

x2=x[,-c(1,8)]
p2=dim(x2)[2]

resB<-optim(betaI,RankB)$par
RankW<-function(b)
{
  eps<-as.vector(y-x2%*%b)
  dd<-abs(outer(eps,eps,FUN="-"))
  dd<-sum(as.vector(dd)*as.vector(dx == 0))/M
  dd
}
resW<-optim(betaI[-c(1,8)],RankW)$par





#vw=cov_uw(resW)
vb=cov_u(resB,w)$covu
vw=fVw(resW)
Gammab=diag(1,p)/M
Gammaw=diag(1,p2)/M

T=Gammab+1
T2=Gammaw+1
itn=0
while(max(abs((Gammab-T)/Gammab),abs((Gammaw-T2)))>0.001){
  
  
  bb=resB
  nb=resB+0.01
  
  b2=resW
  bb2=resW+0.01
  while(max(abs(nb-bb), abs(bb2-b2))>0.001){
    d=Db(Gammab,bb)
    bb=nb
    nb=bb+solve(d)%*%U2(bb)$obj
    
    d2=Dw(Gammaw,b2)
    b2=bb2
    bb2=b2+solve(d2)%*%U3(b2)$obj
    
  }
  itn=itn+1
  
  T=Gammab
  
  Gammab=(solve(d)%*%vb%*%solve(d))
  
  T2=Gammaw
  Gammaw=(solve(d2)%*%vw%*%solve(d2))
}


sim=3000
ub=matrix(NA,nr=sim,nc=p)
uw=matrix(NA,nr=sim,nc=p2)
for(g in 1:sim)
{
  
  ww<-rgamma(N,1,1)
  wii<-rep(ww,times=ni)
  wij<-outer(wii,wii,"*")
  ub[g,]=Ubw(resB,wij)
  uw[g,]=Uww(resW,wij)
  
  #ub[g,]=ubw(resB,ww)
  #uw[g,]=uww(resW,ww)
  print(g)
}

Vbw<-cov(ub,uw)



sigma1<-cbind(vb,Vbw)
sigma2<-cbind(t(Vbw),vw)

sigma<-rbind(sigma1,sigma2)

db<-Db(Gammab,resB)
dw=Dw(Gammaw,resW)
dww<-rbind(0,dw,0)
D<-cbind(db,dww)

hh<-D%*%solve(sigma)
bb=db%*%resB
aa=dw%*%resW
vcs=solve(hh%*%t(D))
betaC<-vcs%*%hh%*%rbind(bb,aa)
optim(betaI,Uc)$par
SE_C=sqrt(diag(vcs))

#################################################################
# the estimates by proposed method
#################################################################

Z1=Sys.time()

M2=sum(ni^2)
M3=sum(ni^3)
M4=sum(ni^4)

n0=rep(0,M)
nn=rep(ni,times=ni)
n0i=outer(n0,nn,"+")
ni1=nn-1
ni10=outer(ni1,n0,"+")
mni=rep(M-ni,times=ni)
mni0=outer(mni,n0,"+")
nii1=rep(ni*(ni-1),times=ni)
nii10=outer(nii1,n0,"+")
nni=outer((M-nn),nn,"-")

d22=matrix(1,nrow=ni[1])
for (i in 1:(N-1)) {
  d22=adiag(d22,matrix(1,nrow=ni[i+1]))
}

############################
#
#############################
a1=(M-ni)
a2= M2-ni^2
a12=a1^2-a2
a21=a2-a1
############################
#for  correlation coefficients
############################
d11=(M3-3*M2+2*M)
dd2=(M4-6*M3+11*M2-6*M)
d33=(M2*(1+M)-M3-M^2)
d44=2*M^2-(3*M+2)*M2+(3+M)*M3-M4
d55=(1+M)*M2-M3-M^2
d66=M^2-(2*M+1-M2)*M2+2*M3-M4
d77=M^3+2*M3-3*M*M2
d88=2*M4-M^3-2*(M+1)*M3+ (M^2+3*M-M2)*M2

p1=p2=0.5
p11=p1^2
p12=p1*p2
p22=p2^2

sigma11=p1*(1-p1)
sigma22=p2*(1-p2)
sigma1=sqrt(sigma11)
sigma2=sqrt(sigma22)
sigma12=sigma1*sigma2

rho1=rho7=1/3
rho2=rho4=0
XX=array(0,dim=c(M,M,p))
Dij=NULL
for(i in 1:p){
  
  XX[,,i]=outer(x[,i],x[,i],"-")
  dij=colSums(XX[,,i])/M
  Dij=rbind(Dij,dij)
}

beta33=betaI
index<-0
iter<-1
while(iter<=10)
{
  
  ##########################################################
  #  estimate sigma_1, sigma_2 and (rho_k,k=0,...,8)
  # eight types of correlation coefficients
  ##########################################################
  #beta2=beta22
  #rhoop=rhof(beta2)
  #digVop=digVf(rhoop)
  #covop=covf(rhoop)
  #Vop=t(covop)+digVop+covop
  #beta22=optim(beta2,rankop)$par
  
  beta3=beta33
  rhojy3=rhof(beta3)
  IdigV=IdigVf(rhojy3)
  beta33=optim(beta3,rankjy3)$par
  if(max(abs(beta3-beta33))<=10^(-4)){index=1;break}
  else{iter<-iter+1}
  
}
print(iter)

betaO=beta33


nsim<-5000	
resb<-resjy<-matrix(NA,nc=p,nr=nsim)
beta33=betaO
rhojy3=rhof(beta33)

for (i in 1:nsim)
{
  ww<-rgamma(N,1,1)
  ww<-rep(ww,times=ni)
  wij<-outer(ww,ww,"*")
  resjy[i,]<-optim(betaI,Rankjyw)$par
  index<-0
  iter<-1
  bit=obj=NULL
  
  
  while(iter<=10)
  {
    beta3=beta33
    
    bb=optim(betaI,rankwop)
    beta33=bb$par
    bit=rbind(bit,beta33)
    obj=c(obj,bb$value)   
    if(max(abs(beta3-beta33))<=10^(-4)){index=1;break}
    else{iter<-iter+1}
    
  }
  if(iter==11){resb[i,]=unique(bit[obj==min(obj),])}
  else{ resb[i,]=beta33}
  print(c(i,iter))
}

SE_OP=sqrt(diag(cov(resb)))
SE_JY=sqrt(diag(cov(resjy)))

cbind(SE_JY,SE_WZ,SE_C,SE_OP)
print(cbind(betaI,betaWZ,betaC,betaO),digits=2)

pjy=1-pnorm(abs(betaI/SE_JY))
pwz=1-pnorm(abs(betaWZ/SE_WZ))
pc=1-pnorm(abs(betaC/SE_C))
pn=1-pnorm(abs(betaO/SE_OP))


res=cbind(betaI,SE_JY,pjy, betaWZ,SE_WZ,pwz,betaC,SE_C,pc,betaO,SE_OP,pn,betaEX[-1], SE_EX[-1],p_EX[-1],betaAR[-1], SE_AR[-1],p_AR[-1])
colnames(res)=c("betaI","SE_JY","pjy", "betaWZ","SE_WZ","pwz","betaC","SE_C","pc","betaO","SE_OP","pn","betaEX", "SE_EX","p_EX","betaAR","SE_AR","p_AR")

res