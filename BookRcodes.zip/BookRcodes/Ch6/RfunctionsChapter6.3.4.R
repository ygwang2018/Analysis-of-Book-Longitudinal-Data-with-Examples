##################################
# function {AR(rho)}_{kl}=rho^|k-l| 
################################
ar=function(rho,n)
{
  e=1:n
  rho^abs(outer(e,e,"-"))
  
}



#####################################
# EX
##################################
cs<- function(rho,n) {
  lags<-matrix(1,n,n)-diag(1,n,n)
  rho^lags 
}
####################################
#MA(1)
####################################
ma=function(rho,n){
  out=diag(n)/2
  out[row(out)==col(out)+1]=rho
  out+t(out)
}
####################################
#inverse matrix
####################################
cs.inv=function(rho,n){
  
 inv=1/(1-rho)*diag(n)-rho/((1-rho)*(1+(n-1)*rho))*matrix(1,nc=n,nr=n)
  
  return(inv)
}


ar.inv=function(rho,n){
  
  inv=1/(1-rho^2)*(ma(-rho,n)+diag(c(0,rep(rho^2,n-2),0)))

}


##################################################
# Toeplitz matrix
####################################################
top=function(rho){
  
  a=c(1,rho)
  toeplitz(a)
  
}

RNi=function(n,rho,tau){
  a=tau*(1-tau)
  rh=rho^(abs(outer(1:n,1:n,"-")))[1,]
  Ctau=NULL
  for(i in 2:n){
    ct= (pmvnorm(lower=c(-Inf, -Inf),upper=c(qnorm(tau),qnorm(tau)),corr=matrix(c(1,rh[i],rh[i],1),2,2))-tau^2)/a
    Ctau=c(Ctau,ct)
  }
  Ri=toeplitz(c(1,Ctau))
  return(Ri)
  
}
#######################################################################
REX=function(n,rho,tau)
{
  
  lags<-matrix(1,n,n)-diag(1,n,n)
  
  Ctau= pmvnorm(lower=c(-Inf, -Inf),upper=c(qnorm(tau),qnorm(tau)),corr=matrix(c(1,rho,rho,1),2,2))
  
  a=tau*(1-tau)
  rk=(Ctau-tau^2)/a
  
  
  rk^lags
  
}
RAR=function(n,rho,tau)
{
  
  
  Ctau= pmvnorm(lower=c(-Inf, -Inf),upper=c(qnorm(tau),qnorm(tau)),corr=matrix(c(1,rho,rho,1),2,2))
  
  a=tau*(1-tau)
  rk=(Ctau-tau^2)/a
  e=1:n
  rk^abs(outer(e,e,"-"))
  
}
#########################################
#  MA1
##############################################
RMA=function(n,rho,tau)
{
  
  out=diag(n)/2
  
  Ctau= pmvnorm(lower=c(-Inf, -Inf),upper=c(qnorm(tau),qnorm(tau)),corr=matrix(c(1,rho,rho,1),2,2))
  
  rk=(Ctau-tau^2)/(tau-tau^2)
  
  
  out[row(out)==col(out)+1]=rk
  out+t(out)
  
}

################################################

##########################################
oum=function(q,n){
  
  out=diag(0,n)
  out[row(out)==col(out)+q]=1
  out+t(out)
}
################################################
#likelihood function


lk.ex=function(alph){
  
  err=y-x%*%betaex
  
  lkh=0
  #c=sqrt(tau*(1-tau))
  
  for(i in 1:m){
    ni=nii[i]
    
    Ai.inv=diag(rep(1/cc,ni))
    Ri.inv=cs.inv(rho=alph,n=ni)
    psi=(err[dat$id==i]<=0)-tau
    
    Vi.inv=Ai.inv%*%Ri.inv%*%Ai.inv
    dVi=(cc^ni)*(1+(ni-1)*alph)*(1-alph)^(ni-1)
    
    lkh=lkh-0.5*(log(dVi)+t(psi)%*%Vi.inv%*%psi)
    
  }
  
  return(lkh)
  
}

lk.ar=function(alph){
  
  err=y-x%*%betaar
  
  lkh=0
  # cc=sqrt(tau*(1-tau))
  for(i in 1:m){
    ni=nii[i]
    Ai.inv=diag(rep(1/cc,ni))
    Ri.inv=ar.inv(rho=alph,n=ni)
    psi=(err[dat$id==i]<=0)-tau
    Vi.inv=Ai.inv%*%Ri.inv%*%Ai.inv
    dVi=(1-alph^2)^(ni-1)*(cc^ni)
    
    lkh=lkh-0.5*(log(dVi)+t(psi)%*%Vi.inv%*%psi)
    
  }
  
  return(lkh)
  
}
lk.ma=function(alph){
  
  err=y-x%*%betama
  
  lkh=0
  #cc=sqrt(tau*(1-tau))
  for(i in 1:m){
    ni=nii[i]
    Ai=diag(rep(cc,ni))
    Ri=ma(rho=alph,n=ni)
    psi=(err[dat$id==i]<=0)-tau
    Vi=Ai%*%Ri%*%Ai
    
    lkh=lkh-0.5*(log(det(Vi))+t(psi)%*%solve(Vi)%*%psi)
    
  }
  
  return(lkh)
  
}


lk.crit=function(y,x,m,beta,alph,tau,str){
  
  err=y-x%*%beta
  
  lkh=0
  cc=sqrt(tau*(1-tau))
  
  for(i in 1:m){
    ni=nii[i]
    Ai=diag(rep(cc,ni))
    Ai.inv=diag(rep(1/cc,ni))
    if(str=="in"){
      Ri=diag(rep(1,ni))
      Vi=Ai%*%Ri%*%Ai
      Vi.inv=Ai.inv%*%Ri%*%Ai.inv
    } else if(str=="ex"){
      Ri=cs(rho=alph,n=ni)
      Vi=Ai%*%Ri%*%Ai
      Ri.inv=cs.inv(rho=alph,n=ni)
      Vi.inv=Ai.inv%*%Ri.inv%*%Ai.inv
      dVi=(cc^ni)*(1+(ni-1)*alph)*(1-alph)^(ni-1)
    } else if(str=="ar"){
      Ri=ar(rho=alph,n=ni)  
      Vi=Ai%*%Ri%*%Ai
      Ri.inv=ar.inv(rho=alph,n=ni)
      Vi.inv=Ai.inv%*%Ri.inv%*%Ai.inv
    } else if(str=="ma"){
      Ri=ma(rho=alph,n=ni)
      Vi=Ai%*%Ri%*%Ai
      Vi.inv=Ai.inv%*%solve(Ri)%*%Ai.inv
    } else Ri=top(rho=alph) 
    psi=(err[dat$id==i]<=0)-tau
    
    
    lkh=lkh-0.5*(log(det(2*pi*Vi))+t(psi)%*%Vi.inv%*%psi)
    
  }
  GLH=-2*lkh
  
  return(GLH)
  
}

