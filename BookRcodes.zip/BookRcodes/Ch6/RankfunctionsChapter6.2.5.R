##########################################################
# total loss function based on the independence working model
#########################################################
rankjy=function(b){
eps=as.vector(y-x%*%b)
ep=as.vector(abs(outer(eps,eps,"-")))
d=sum(ep)/M^2
d
}

#################################################################
# estimate the weight function using the method proposed by Wang and Zhao
################################################################# 
 weight=function(b){
   eps=as.vector(y-x%*%b)
   er=rank(eps)-(M+1)/2   
 a=outer(er,er,"*")*(dx==0)
 numer=sum(a)-sum(diag(a))
 b=rep((ni-1),times=ni)
 denom=sum(b*er^2)
 rho_mom=numer/denom 
 w=rep(1/(1+(ni-1)*rho_mom),times=ni)

list(w=w, rho_mom=rho_mom)
 }
######################################################
# the objective function using simple weighted method
######################################################
 rankwz=function(b){
 eps=as.vector(y-x%*%b)
 wobj=as.vector(outer(w,w,"*"))*as.vector(abs(outer(eps,eps,"-")))
 obj=sum(wobj*(as.vector(dx>0)))/M^2
 obj
 } 
 

#########################################
#covariance of the estimating functions
########################################

cov_u=function(b,wgt){

	resi=y-x%*%b
	
	eta=matrix(0,nr=N,nc=p)
		for (i in 1:N){
			for(j in 1:N){	
			    if(j==i) next
			    eoe=outer(resi[id==i],resi[id==j],">")-1/2
			    xi=matrix(x[id==i],nc=p)
			    xj=matrix(x[id==j],nc=p)
			    xik=xjl=rep(0,p)	
			    for(k in 1:ni[i]) xik=xik+xi[k,]*sum(eoe[k,])
			    for(l in 1:ni[j]) xjl=xjl+xj[l,]*sum(eoe[,l])
			    eta[i,]=eta[i,]+wgt[id==i][1]*wgt[id==j][1]*(xik-xjl)	
			}		
		}
	temp3=matrix(0,nr=p,nc=p)
	for(i in 1:N) temp3=temp3+eta[i,]%o%eta[i,]
	varu=16*temp3/(M^4)
	varu
        #cat("The asymptotic covariance matrix of E.F","\n",varu)
	list(covu=varu)
}


######value of E.F##################################################################
#the simple weighted estimating function
##############################################################################
u_value=function(b,wgt){
	sgn=function(x,y){
		sign(x-y)
    	}	
	resi=y-x%*%b
	
	ui=matrix(0,nr=N,nc=p)
		for (i in 1:N){
			for(j in 1:N){	
			    if(j==i) next
			    eoe=outer(resi[id==i],resi[id==j],"sgn")
			    xi=matrix(x[id==i],nc=p)
			    xj=matrix(x[id==j],nc=p)
			    xik=xjl=rep(0,p)	
			    for(k in 1:ni[i]) xik=xik+xi[k,]*sum(eoe[k,])
			    #for(l in 1:ni[j]) xjl=xjl+xj[l,]*sum(eoe[,l])
			    #ui[i,]=ui[i,]+wgt[id==i][1]*wgt[id==j][1]*(xik-xjl)	
			    ui[i,]=ui[i,]+wgt[id==i][1]*wgt[id==j][1]*(xik)
			}		
		}
u=2*apply(ui,2,"sum")/(M^2)
list(u=u)
}
###########################################################################



########Cov of parameters#########################################
#the smoothing between cluster estimating functions 
######################################################################
U2=function(bb){
	d=rep(0,p);

	ee=y-x%*%bb
	for (i in 1:N){
	for(j in 1:N){	
		if(j==i) next
		    xi=matrix(x[id==i],nc=p)
		    xj=matrix(x[id==j],nc=p)
			
		    for(k in 1:ni[i]){ 
		         for(l in 1:ni[j]){
				 b=c=0
				 b=sqrt((xi[k,]-xj[l,])%*%Gammb%*%(xi[k,]-xj[l,]))
				 
				 if(b==0)next	
				 c=(ee[id==i][k]-ee[id==j][l])/b			 
				
		    	     	 d=d+as.numeric(w[id==i][1]*w[id==j][1])*(xi[k,]-xj[l,])*(2*pnorm(c)-1)
			 }    
				
		    }
	}
}	
list(obj=d/M^2)
}

###########################################################################


#########################################################
# the objective function based on the between clusters
#######################################################
RankB<-function(b)
{
	eps<-as.vector(y-x%*%b)
	dd<-abs(outer(eps,eps,FUN="-"))
	dd<-sum(as.vector(dd)*as.vector(dx>0))/M^2
}





#########################################################
# the estimating functions based on the between clusters
#######################################################

Ubw<-function(b,wij)
{
eps<-as.vector(y-x%*%b)
dd<-sign(outer(eps,eps,FUN="-"))
Ub=colSums(X2*as.vector(dd)*as.vector(dx>0)*as.vector(wij))/M^2
Ub
}

#########################################################
# the estimating functions based on the within clusters
#######################################################
Uww<-function(b,wii)
{
eps<-as.vector(y-x2%*%b)
dd<-sign(outer(eps,eps,FUN="-"))
Uw=colSums(X2[,-c(1,8)]*as.vector(dd)*as.vector(dx==0)*as.vector(wii))/M
Uw
}

########Cov of parameters#########################################
#the smoothing within cluster estimating functions 
######################################################################
U3=function(bb){
	d=rep(0,p2)

	ee=y-x2%*%bb
	for (i in 1:N){
		    xi=matrix(x2[id==i],nc=p2)
		    for(k in 1:ni[i]){ 
		         for(l in 1:ni[i]){
                         if(l==k) next
				 b=c=0
				 b=sqrt((xi[k,]-xi[l,])%*%Gammaw%*%(xi[k,]-xi[l,]))
				 if(b==0)next	
				 c=(ee[id==i][k]-ee[id==i][l])/b
		    	     	 d=d+(xi[k,]-xi[l,])*(2*pnorm(c)-1)
			 }    
				
	}
}	
list(obj=d/M)
}

###########################################################################

Db=function(Gamma, bb)
{

d=0
ee=y-x%*%bb
for (i in 1:N){
	for(j in 1:N){	
		if(j==i) next
		    xi=matrix(x[id==i],nc=p)
		    xj=matrix(x[id==j],nc=p)
			
		    for(k in 1:ni[i]){ 
		         for(l in 1:ni[j]){
				 b=c=0
				 b=sqrt((xi[k,]-xj[l,])%*%Gamma%*%(xi[k,]-xj[l,]))	
				 if(b==0)next	
				 c=(ee[id==i][k]-ee[id==j][l])/b
                         ib=1/b
		    	     	 d=d+as.numeric(w[id==i][1]*w[id==j][1]*dnorm(c)*ib)*((xi[k,]-xj[l,])%o%(xi[k,]-xj[l,]))
			 }  
}  
	}
}	
d=2*d/M^2
}

########################################################

Dw=function(Gamma, bb)
{
d=0

ee=y-x2%*%bb
for (i in 1:N){
	 xi=matrix(x2[id==i],nc=p2)
		   			
		    for(k in 1:ni[i]){ 
		         for(l in 1:ni[i]){
                      if(l==k) next
				 b=c=0
				 b=sqrt((xi[k,]-xi[l,])%*%Gamma%*%(xi[k,]-xi[l,]))
				 if(b==0)next	
				 c=(ee[id==i][k]-ee[id==i][l])/b
                         ib=1/b
		    	     	 d=d+c(dnorm(c)*ib)*((xi[k,]-xi[l,])%o%(xi[k,]-xi[l,]))
			 }    
	}
}	
d=2*d/M
}


fVw<-function(b)
{ 
    
  Vw<-matrix(0,p2,p2)
  er<-y-x2%*%b
     for(i in 1:N)
       {
        t1=(id==i)
         xx1<-matrix(x2[t1,],nc=p2)
         eps1=er[t1]
        # if(sum(t1)==1) xx1<-t(xx1)
               xx3=NULL
               for(k in 1:p2){
                   xx3<-cbind(xx3,as.vector(outer(xx1[,k],xx1[,k],"-")))
                      }
      
                eps<-as.vector(outer(eps1,eps1,"-"))
               xx<-xx3*(eps>0)
           eti=apply(xx,2,sum)   
     Vw<-Vw+(eti)%*%t(eti) 
           
             }
4*Vw/M^2
}


fVbw<-function(b1,b2)
{

Vbw<-matrix(0,p,p2)

 eps<-y-x%*%b1
 res<-y-x2%*%b2

 for(i in 1:N)
       {
    
         xab<-matrix(x[id==i,],nc=p)
          ti=sum(id==i)
         
         if(ti==1)xab<-t(xab)
xx1=matrix(NA,nr=M*ti,nc=p)
xx2=matrix(NA,nr=ti*ti,nc=p)
for(r in 1:p){
         xx1[,r]<-as.vector(outer(xab[,r],x[,r],"-"))
         xx2[,r]=as.vector(outer(xab[,r],xab[,r],"-"))
         }

         er<-as.vector(outer(eps[id==i],eps,"-"))
         xx<-xx1*((er>0)-0.5)
         zz<-apply(xx1,2,sum)
         
         eri<-as.vector(outer(eps[id==i],eps[id==i],"-"))
         xxi<-xx2*((eri>0)-0.5)
         dd<-apply(xxi,2,sum)
         psi<-2/M*(zz-dd)  

xw<-matrix(x2[id==i,],nc=p2)
if(ti==1)xw<-t(xw)
xx3=matrix(NA,nr=ti^2,nc=p2)
for(g in 1:p2)
{
         xx3[,g]<-as.vector(outer(xw[,g],xw[,g],"-"))
}
              err<-as.vector(outer(res[id==i],res[id==i],"-"))
         xxi<-xx3*((err>0))
         eti<-apply(xxi,2,sum)
       
          Vbw<-Vbw+ as.matrix(psi)%*%eti 
                    }
8*Vbw/M^3
}








##############################################
# the combined estimating functions
###############################################
Uc=function(b)
{

eps<-as.vector(y-x%*%b)
dd<-sign(outer(eps,eps,FUN="-"))
Ub=colSums(X2*as.vector(dd)*as.vector(dx>0))/M^2
Ub=as.matrix(Ub)
epw<-as.vector(y-x2%*%b[-1])
ddw<-sign(outer(epw,epw,FUN="-"))
Uw=colSums(X2[,-c(1,8)]*as.vector(ddw)*as.vector(dx==0))/M
Uw=as.matrix(Uw)


#xxb=X2*as.vector((dx>0))
#xxw=X2*as.vector((dx==0))
Uc=D%*%solve(sigma)%*%rbind(Ub,Uw)
t(Uc)%*%Uc
}








###########################################################
# our method
###########################################################

Df=function(b){

eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
#w=rep(wi,times=ni)
D=NULL
  for(j in 1:M){
  xxij=cbind(XX[j,,1],XX[j,,2])
  Dij=1/(M-1)*colSums(xxij)
  D=cbind(D,Dij)
  }       

 D

}
#######################################################
#        variance matrix of the  estimating functions
#######################################################

 rankop=function(b)
{
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
ddx=(ee<0)
rankee=colSums(ddx-1/2)
S=rankee/M
d=Dij[,-1]%*%solve(Vop[-1,][,-1])%*%S[-1]
t(d)%*%d                                                                                         

}



rankjy2=function(b)
{
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
ddx=(ee<0)
rankee=colSums(ddx-1/2)
S=rankee/(M)
d=Dij[,-1]%*%solve(digVjy2[-1,][,-1])%*%S[-1]
t(d)%*%d

}
rankjy3=function(b)
{
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
ddx=(ee<0)
rankee=colSums(ddx-1/2)
S=rankee/(M)
  #  IdigV=solve(digVjy2)
d=Dij%*%IdigV%*%S
t(d)%*%d

}

rhof=function(b){
    
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
eex=(ee<0)
wdx=eex*(dx==0)
bdx=eex*(dx>0)
  #p1=sum(wdx)/(M2-M)
  #p2=sum(bdx)/(M^2-M2)
 
  bas=rowSums(wdx)
  d1=sum(bas^2)
  d2=sum((bas%*%d22)^2)
  bbas=rowSums(bdx)

  bbs=(bdx%*%d22)

  d3=sum(bbs^2)
  d4=sum(bbas^2)

  d5= sum((bbas%*%d22)^2)
  see=rowSums(eex)
  d6=sum(see^2)
  d7= sum((see%*%d22)^2)
  d8=sum((t(d22)%*%bbs)^2)

# rho1=((2*d1-2*sum(ni10*wdx)+d11)/(2*d11) -p11)/sigma11

#  rho2=((d2-sum(bas)-d11)/dd2-p11)/sigma11

  rho3=((d6-d1-d4+d33-sum(mni0*wdx)-sum(ni10*bdx))/(2*d33)-p12)/sigma12

 #rho4=((d7-d2-d5+d44-sum(nii10*bdx)-sum((ni10-1)*mni0*wdx))/(2*d44)-p12)/sigma12


  D5= 2*d3-2*sum(bdx*n0i)+d55
  rho5=(D5/(2*d55)-p22)/ sigma22
  rho6=((d8-D5-sum(bdx) )/d66-p22)/sigma22

 # rho7= (((2*(d4-d3)+d77-2* sum(nni*bdx)) )/(2*d77)- p22)/ sigma22

  rho8= ((2*(d5+d3-d4-d8)+d88-2*sum(ni10*nni*bdx) )/(2*d88)-p22)/ sigma22

   hatrho=c(rho1,rho2,rho3,rho4,rho5,rho6,rho7,rho8)
      hatrho
      }
      
      
      
digVf=function(rh){   
     
 v1=((a1+a21*rh[5]+ a12*rh[7])*sigma22+(ni-1)*(1+(ni-2)*rh[1])*sigma11+2*(ni-1)*a1*rh[3]*sigma12)/M^2
 v2=((a1*rh[5]+ a21*rh[6]+ a12*rh[8])*sigma22+2* a1*((ni-2)*rh[4]-rh[3])*sigma12-sigma11+(ni-2)*((ni-3)*rh[2]-rh[1])*sigma11)/M^2

J1=matrix(1,nrow=ni[1],ncol=ni[1])
digV=(v1[1]-v2[1])*diag(1,ni[1])+ v2[1]*J1

for(i in 2:N){
Ji=matrix(1,ncol=ni[i],nrow=ni[i])
  Vi=(v1[i]-v2[i])*diag(1,ni[i])+ v2[i]*Ji
  digV=adiag(digV,Vi)

}

digV
    }

covf=function(rh){
  
     VV=NULL
 for(i in 1:(N-1))
 {

      Vij=matrix(0,nrow=ni[i],ncol=sum(ni[1:i]))
   for(j in (i+1):N)
  {       
       eij= matrix(1,nrow=ni[i],ncol=ni[j])
          nij=ni[i]+ni[j]
          mnij= M-nij
             vij=1/(M)^2*((-mnij*rh[7]+((M2-ni[i]^2-ni[j]^2)-mnij*(nij-1))*rh[8]-1-(nij-2)*rh[5]-(ni[i]-1)*(ni[j]-1)*rh[6])*sigma22+((ni[i]-1)*(ni[i]-2)-(ni[j]-1)*(ni[j]-2))*rh[4]*sigma12)

             Vij=cbind(Vij,vij*eij)
                }

            VV=rbind(VV,Vij)

           }
  CV=rbind(VV,matrix(0,ni[N],M))

      CV

    }



IdigVf=function(rh){     
 v1=((a1+a21*rh[5]+ a12*rh[7])*sigma22+(ni-1)*(1+(ni-2)*rh[1])*sigma11+2*(ni-1)*a1*rh[3]*sigma12)/(M-1)^2
 v2=((a1*rh[5]+ a21*rh[6]+ a12*rh[8])*sigma22+2* a1*((ni-2)*rh[4]-rh[3])*sigma12-sigma11+(ni-2)*((ni-3)*rh[2]-rh[1])*sigma11)/(M-1)^2
J1=matrix(1,ncol=ni[1],nrow=ni[1])
IdigV=1/(v1[1]-v2[1])*(diag(1,ni[1])- v2[1]/(v1[1]+(ni[1]-1)*v2[1])*J1 )

for(i in 2:N){
Ji=matrix(1,ncol=ni[i],nrow=ni[i])
  IVi=1/(v1[i]-v2[i])*(diag(1,ni[i])-v2[i]/(v1[i]+(ni[i]-1)*v2[i])*Ji)
  IdigV=adiag(IdigV,IVi)

}

IdigV
    }

#######################################################
# DD   The derivative   of estimating functions
########################################################
ds=function(b,Gam){

eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
#w=rep(wi,times=ni)
D=NULL
  for(j in 1:M){
  xxij=cbind(XX[j,,1],XX[j,,2])
  s1=xxij%*%solve(Gam)%*%t(xxij)
  rij=sqrt(diag(s1)) 
     #
  ss=xxij/rij *dnorm(ee[j,]/rij)
   ss[is.na(ss)] =0
   Dij=1/(M-1)*colSums(ss)
  D=cbind(D,Dij)
  }       

 D
 
}

########################################################################
#the distributed objective functions based on independence working model
###########################################################################
     Rankjyw<-function(b) 
{
     	eps<- as.vector(y-x%*%as.matrix(b))
	dd<-abs(outer(eps,eps,FUN="-"))
	dd<-sum(as.vector(dd*wij))
	(dd/N^2)
}

rankwop=function(b)
{
eps=as.vector(y-x%*%b)
ee=outer(eps,eps,"-")
ddx=(ee<0)
S=ww*colSums(ddx-1/2)/M
d=Dij%*%IdigV%*%S
t(d)%*%d

}



